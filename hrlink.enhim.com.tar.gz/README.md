# Инструкция по развёртыванию приложения HRlink

## Требования к окружению и инфраструктуре

1. Настроен сервер для разворота приложения

   Минимальные требования к серверу:

      - OS - Ubuntu 22.04 LTS, РЕД ОС, Astra Linux.
      - CPU - 8 ядер 2ГГц
      - RAM - 12Гб RAM
      - Диск: 250Гб SSD + место под файлы из расчета 2Мбайт на один документ (и 50 документов на одного сотрудника в год)

2. На сервере установлены:

   - `docker` - версия не ниже 23.0
   - `docker-compose` - версия не ниже 2.24.1
   - `bash`
   - `nano`
   - `vim`
   - `htop`
   - `uuidgen`
   - `ping`
   - `curl`
   - `netcat`
   - `ss` или `netstat`
   - `cron`
   - `openssl`

3. С сервера открыт доступ к адресам:

   - <https://license.hr-link.ru>
   - <https://zorro.hr-link.ru>
   - <https://docker.hr-link.ru>
   - <https://pinboard.hr-link.ru>
   - <https://hrlk.ru>
   - <https://pechkin.hr-link.ru>
   - <https://esa.hr-link.ru>
   - <https://trudvsem.hr-link.ru>
   - <https://ekd-integration.trudvsem.ru>
   - <https://kronos.hr-link.ru>

4. Приложение HRlink должно принимать запросы со следующих адресов:

   - 185.149.241.95
   - 92.53.74.92
   - 185.99.9.36-185.99.9.62
   - 185.242.121.17

5. На сервере не должно быть приложений занимающих порты `443` и `80`.

6. В случае использования прокси-сервера над приложением необходимо явно проксировать hop-by-hop заголовки Upgrade и Connection.

   Пример настроек для веб-сервера nginx:

   ```nginx
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection "upgrade";
   ```

7. На сервере выбрана директория, в которой будут размещаться все файлы приложения. Далее в тексте эта директория упоминается как `$HRLINK_HOME`.

8. Существует учетная запись пользователя, от имени которого будут выполняться все действия по развороту и обслуживанию приложения.

   - Пользователь должен иметь полные права на директорию `$HRLINK_HOME` и права для запуска `docker` и `docker compose`.
   Как это сделать, описано в инструкции по ссылке: <https://docs.docker.com/engine/install/linux-postinstall/>, раздел `Manage Docker as a non-root user`. И/или пользователь должен иметь права супер-пользователя.

9. Существует доменное имя третьего уровня (или FQDN), на котором будет доступно web-приложение HRlink. Далее по тексту инструкции будем называть этот домен доменом приложения.

!!! **Доменное имя должно быть доступно для запросов из Интернета, т.к. сервисы подписания документов будут отправлять на него callback'и** !!!

10. Существует файл SSL-сертификата (.pem или .crt) и файл приватного ключа(.key) для nginx, содержащий полную цепочку сертификатов, включая промежуточные и корневые сертификаты Удостоверящих Центров. SSL-сертификат должен быть выпущен публичным Удостоверяющим Центром, самоподписанные сертификаты приложением не поддерживаются.

!!! **SSL-сертификат может не требоваться, если терминирование SSL будет происходить на внешнем веб-сервере клиента** !!!

11. От инженеров HRlink должен быть получен архив, содержащий файлы, необходимые для запуска приложения.

## Шаги по развёртыванию

1. Распаковать архив с файлами приложения в рабочую директорию. Содержимое рабочей директории должно быть следующим:
   - `docker-compose.yaml` - файл с инструкциями для утилиты docker-compose;
   - `scripts/` - директория, содержащая скрипты, необходимые для разворота и поддержки приложения;
   - `nginx.conf` - файл конфигурации для внутреннего nginx-сервера приложения;
   - `nginx/` - директория, содержащая внешние файлы nginx-сервера;
   - `ekd-config/` - директория, содержащая файлы конфигурации приложения;
   - `certs/` - директория, в которой будут храниться SSL-сертификаты (если требуется);
   - `credentials.txt` - файл, содержащий учётные данные для доступа к Docker Registry HRlink и лицензионный ключ HRlink;

2. Исполнить скрипт `./scripts/setup/initial_setup.sh`
   1) Скрипт проверит соответствие сервера минимальным требованиям, указанным выше.
   2) Скрипт произведет авторизацию в Docker Registry HRlink (или Вашем Docker Registry).
   3) Скрипт запросит домен приложения. Необходимо ввести домен третьего уровня.
   4) Скрипт запросит цепочку SSL сертификатов, если SSL терминируется в приложении.
   5) Скрипт задаст переменную `$HRLINK_HOME` в `/etc/environment` или `$HOME/.profile`.
   6) Скрипт установит регулярные задачи в `cron`.

!!! **По умолчанию для контейнеров выделена подсеть `172.23.45.0/24`, если она пересекается с подсетями в вашей локальной сети - нужно изменить подсеть.**
**Для этого в файле `$HRLINK_HOME/docker-compose.yaml` в свойстве subnet нужно указать свою подсеть. В указанной подсети должно быть не менее 15 хостов.** !!!

3. Проверить состояние контейнеров командой `docker compose ps`. Всего должно быть запущено 11 контейнеров, и все они должны иметь статус UP.

   После запуска приложения в рабочей директории дополнительно появится следующее содержимое:

   1) `logs/` - директория содержащая логи микросервисов.
   2) `ekd-monolith-storage/` - директория содердащая пользовательские файлы.
   3) `postgresql-data/` - директория содержащая данные БД.

5. После того, как контейнеры запустились, приложению нужно некоторое время (около 5 минут), чтобы запуститься внутри контейнеров.

```
NAME                      IMAGE                                              COMMAND                  SERVICE                   CREATED         STATUS                   PORTS
ekd-api-gateway           docker.hr-link.ru/ekd/ekd-api-gateway:77           "/var/hrlink/bash/en…"   ekd-api-gateway           2 minutes ago   Up 2 minutes (healthy)   
ekd-calendar              docker.hr-link.ru/ekd/ekd-calendar:75              "/var/hrlink/bash/en…"   ekd-calendar              2 minutes ago   Up 2 minutes (healthy)   
ekd-chat                  docker.hr-link.ru/ekd/ekd-chat:75                  "/var/hrlink/bash/en…"   ekd-chat                  2 minutes ago   Up 2 minutes (healthy)   
ekd-file                  docker.hr-link.ru/ekd/ekd-file:77                  "/var/hrlink/bash/en…"   ekd-file                  2 minutes ago   Up 2 minutes (healthy)   
ekd-file-processing       docker.hr-link.ru/ekd/ekd-file-processing:76       "/var/hrlink/bash/en…"   ekd-file-processing       2 minutes ago   Up 2 minutes (healthy)   
ekd-monolith              docker.hr-link.ru/ekd/ekd-monolith:77              "/var/hrlink/bash/en…"   ekd-monolith              2 minutes ago   Up 2 minutes (healthy)   0.0.0.0:8000->8000/tcp, :::8000->8000/tcp
ekd-postgresql            docker.hr-link.ru/postgres:13-alpine               "docker-entrypoint.s…"   postgresql                2 minutes ago   Up 2 minutes (healthy)   0.0.0.0:5432->5432/tcp, :::5432->5432/tcp
ekd-repeat-notification   docker.hr-link.ru/ekd/ekd-repeat-notification:77   "/var/hrlink/bash/en…"   ekd-repeat-notification   2 minutes ago   Up 2 minutes (healthy)   
ekd-showcase              docker.hr-link.ru/ekd/ekd-showcase:75              "/var/hrlink/bash/en…"   ekd-showcase              2 minutes ago   Up 2 minutes (healthy)   0.0.0.0:32769->8000/tcp, :::32769->8000/tcp
ekd-ui                    docker.hr-link.ru/ekd/ekd-ui:77                    "/docker-entrypoint.…"   ekd-ui                    2 minutes ago   Up 2 minutes (healthy)   0.0.0.0:80->80/tcp, :::80->80/tcp, 0.0.0.0:443->443/tcp, :::443->443/tcp
ekd_kafka                 docker.hr-link.ru/kafka:3.6.1                      "/docker-entrypoint.…"   ekd_kafka                 2 minutes ago   Up 2 minutes (healthy)   9092/tcp
```

6. Проверить cтатус приложения выполнив команду `docker exec -it ekd-monolith curl localhost:8000/api/v1/version`. Ответом должен верунться json массив в виде `{"result":true,"version":"2.82.25"}`.

7. Проверить, что в браузере открывается страница с регистрацией <https://client.domain.ru/registration>, где `client.domain.ru` - домен приложения.

## Регистрация пространства

Это действие выполняет администратор пространства (главный кадровый сотрудник).

1. Перейти в браузере на страницу <https://client.domain.ru/registration>, где client.domain.ru это домен приложения.

2. Заполнить форму регистрации следующим образом:

   1) В поле Название ввести название юрлица, а затем через пробел слово Staging в случае инсталляции на стейджинге, или слово Production в случае инсталляции в production-среде.
   2) В поле Email ввести email пользователя, который будет выполнять роль администратора приложения HR-Link. Необходимо ввести существующий email, т.к. на него будет отправлено письмо со ссылкой-подтверждением.
   3) В поле Пароль ввести пароль для пользователя-администратора.
   4) В поле СНИЛС ввести действительный СНИЛС пользователя-администратора.

3. Нажать кнопку "ЗАРЕГИСТРИРОВАТЬСЯ". Необходимо подождать некоторое время (вплоть до минуты), пока завершится процесс регистрации.

4. Подтвердить email администратора, перейдя по ссылке из письма, которое пришло на указанную почту.

5. Перейти на страницу входа в приложение (<https://client.domain.ru/>, где `client.domain.ru` - домен приложения), ввести логин и пароль администратора, и нажать кнопку "ВОЙТИ".
