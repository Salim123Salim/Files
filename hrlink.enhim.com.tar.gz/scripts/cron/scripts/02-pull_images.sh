#!/bin/bash

# проверка на наличие свободного места для скачивания новых образов
disk_space=$(df /var/lib/docker --output=avail | tail -n 1 | awk '{print int($1 / 1024 / 1024)}')
if [[ $disk_space -lt 10 ]]; then
	exit 1
fi

compose_file=$(docker inspect --format '{{ index .Config.Labels "com.docker.compose.project.config_files" }}' ekd-monolith)

# скачивание новых образов
docker compose -f $compose_file pull
