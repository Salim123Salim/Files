#!/bin/bash

compose_file=$(docker inspect --format '{{ index .Config.Labels "com.docker.compose.project.config_files" }}' ekd-monolith)

# применение хотфиксов
docker compose -f $compose_file up -d

# удаление неиспользуемых образов старше 1 недели
docker system prune -af --filter "until=$((24*5))h"
