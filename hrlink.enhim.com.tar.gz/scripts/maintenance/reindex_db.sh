#!/bin/bash

date_filter='%Y-%m-%d_%H-%M-%S'

NEW_RELEASE=79
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +$date_filter)"
UPDATE_LOG_FILE="logs/updates/$NEW_RELEASE.txt"

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

docker_pfx="docker exec ekd-postgresql"

pre_update_checks() {
    ls docker-compose.yaml > /dev/null 2>&1 || { echo "скрипт необходимо запустить из директории с docker-compose.yaml на сервере с контейнером БД"; exit 4; }

    echo "Проверка наличия необходимых пакетов:"
    pkgs=("docker" "bash")

    for pkg in "${pkgs[@]}"; do
        which $pkg > /dev/null 2>&1
        exit_code="$?"

        if [[ $exit_code -eq 0 ]]; then
            printf "$clr_grn\t$pkg найден$clr_rst\n"
        else
            printf "$clr_red\t$pkg не найден!$clr_rst\n"
            pkg_not_found=1
        fi
    done

    if [[ "$pkg_not_found" -gt 0 ]]; then
        printf "$clr_redНеобходимо установить необходимые пакеты перед обновлением!$clr_rst\n"
        exit 1
    fi
}

pre_update_actions() {
    echo "Директория бекапа до обновления - $BACKUP_DIR"
    mkdir -p $BACKUP_DIR
    mkdir -p logs/updates
    touch $UPDATE_LOG_FILE

    cp docker-compose.yaml nginx.conf .env ekd-config/custom.conf $BACKUP_DIR
    cp ekd-config/ekd-file/custom.conf $BACKUP_DIR/ekd-file-custom.conf
}

db_actions() {
    curr_version="$(grep '/postgres:' docker-compose.yaml | head -n 1 | awk -F: '{print $NF}')"
    if [[ -n "$(docker container ls --format 'table {{.Names}}' 2>/dev/null | grep 'ekd-postgresql')" ]]; then
        databases=$(docker exec ekd-postgresql psql -U postgres -A -t -c "SELECT datname FROM pg_database;")
        mapfile -t db_array <<< "$databases"

        echo "Реиндексация БД и переключение postgres:$curr_version на postgres:13-alpine"
        echo "$(date +$date_filter): переключение postgres:$curr_version на postgres:13-alpine" >> $UPDATE_LOG_FILE

        read -p "Остановить приложение? [y/N]: " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            docker compose down || docker-compose down
        else
            echo "Обновление отменено"
            echo "$(date +$date_filter): Обновление отменено" >> $UPDATE_LOG_FILE 2>&1
            exit 2
        fi
        sed -i "s/postgres:$curr_version/postgres:13-alpine/" docker-compose.yaml
        docker compose up -d postgresql || docker-composes up -d postgresql
        sleep 5
        for db in "${db_array[@]}"; do
            echo "$(date +$date_filter): реиндекс бд $db"
            docker exec --user postgres ekd-postgresql reindexdb --concurrently -d "$db" -j 15 -e | awk '{print "\t" $0}'
        done >> $UPDATE_LOG_FILE 2>&1
        echo "Реиндекс баз закончен"
    else
        echo "$(date +$date_filter): контейнер ekd-postgresql не найден" >> $UPDATE_LOG_FILE
        printf "$clr_ylwКонтейнер ekd-postgresql не найден на этом сервере.\nНеобходимо исполнить скрипт reindex_db.sh на сервере с контейнером БД.$clr_rst\n"
    fi
}

pull_images() {
    echo "Cкачиваем новые образы приложения"
    docker compose pull || docker-compose pull
    echo "Удаляем старые образы"
    docker system prune -af --filter "until=$((14*24))h" | grep "Total reclaimed space:"
}

restart_app() {
    docker compose up -d || docker-compose up -d
}


pre_update_checks
pre_update_actions
db_actions
pull_images
restart_app

printf "$clr_grnГотово$clr_rst\n"
