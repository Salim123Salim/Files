#!/bin/bash
set -e

psql -v ON_ERROR_STOP=1 --username postgres --dbname "$POSTGRES_DB" <<-EOSQL
    CREATE USER migrations_user WITH LOGIN SUPERUSER PASSWORD '$MIGRATIONS_USER_PASSWORD';

    CREATE DATABASE ekd_ca;
    CREATE DATABASE ekd_id;
    CREATE DATABASE ekd_ekd;
    CREATE DATABASE ekd_session;
    CREATE DATABASE ekd_metadata;
    CREATE DATABASE ekd_file;
    CREATE DATABASE ekd_request_logger;
    CREATE DATABASE ekd_notification;

    CREATE DATABASE ekd_calendar_db;
    CREATE DATABASE ekd_chat_db;
    CREATE DATABASE ekd_repeat_notification_db;
    CREATE DATABASE ekd_showcase_db;
    CREATE DATABASE ekd_file_processing_db;
EOSQL

psql --username postgres --dbname "$POSTGRES_DB" -c "ALTER SYSTEM SET max_connections = 1000;"
psql --username postgres --dbname "$POSTGRES_DB" -c "ALTER SYSTEM SET shared_preload_libraries = 'pg_stat_statements';"

pg_ctl -D /var/lib/postgresql/data/pgdata restart

psql --username postgres --dbname "$POSTGRES_DB" -c "CREATE EXTENSION IF NOT EXISTS pg_stat_statements;"
psql --username postgres --dbname "$POSTGRES_DB" -c "SELECT pg_reload_conf();"
