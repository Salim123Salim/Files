#!/bin/bash

ignore_errors="$1"

clr_rst='\033[0m'
clr_red='\033[0;31m'
clr_grn='\033[0;32m'

############# проверка соответствию минимальным требованиям по железу ##################################################
min_cpu_cores=8
min_mem_gbs=12
min_disk_space=256

cpu=$(nproc)
if [[ $cpu -lt $min_cpu_cores ]]; then
    printf '%bНа сервере недостаточно ядер CPU (%d, минимум - %d)%b\n' "$clr_red" "$cpu" "$min_cpu_cores" "$clr_rst"
    hw_err=1
else
    printf '%bCPU OK (%d)%b\n' "$clr_grn" "$cpu" "$clr_rst"
fi

mem=$(free -m | awk '/^Mem:/ {printf "%.0f", $2/1024}')
if [[ $mem -lt $min_mem_gbs ]]; then
    printf '%bНа сервере недостаточно GB ОЗУ (%d gb, минимум - %d gb)%b\n' "$clr_red" "$mem" "$min_mem_gbs" "$clr_rst"
    hw_err=1
else
    printf '%bMEM OK (%d gb)%b\n' "$clr_grn" "$mem" "$clr_rst"
fi

disk_space=$(df --total --output=size -x loop -x tmpfs | tail -n 1 | awk '{print int($1 / 1024 / 1024)}')
if [[ $disk_space -lt $min_disk_space ]]; then
    printf '%bНа сервере недостаточно места на диске (%d gb, минимум - %d gb)%b\n' "$clr_red" "$disk_space" "$min_disk_space" "$clr_rst"
    hw_err=1
else
    printf '%bDISK OK (%d gb) %b\n' "$clr_grn" "$disk_space" "$clr_rst"
fi

if ! [[ $hw_err -eq 0 ]] && ! [[ $ignore_errors -eq 0 ]]; then
    exit 1
fi
########################################################################################################################

##################### проверка прав текущего пользователя ##############################################################
if [[ $(id -u) -eq 0 || $(id -nG) =~ (^|[[:space:]])docker($|[[:space:]]) ]]; then 
    printf '%bТекущий пользователь имеет доступ к docker%b\n' "$clr_grn" "$clr_rst"
else
    printf '%bТекущий пользователь не имеет доступ к docker%b\n' "$clr_red" "$clr_rst"
    exit 1
fi

if [ ! -w . ]; then
    printf '%bТекущий пользователь не имеет права изменять директорию приложения%b\n' "$clr_red" "$clr_rst"
    exit 1
else
    printf '%bТекущий пользователь имеет права изменять директорию приложения%b\n' "$clr_grn" "$clr_rst"
fi
########################################################################################################################

############# наличие необходимых пакетов и версии docker ##############################################################
docker_engine_min_version=23
docker_compose_min_major_version=2
docker_compose_min_minor_version=24

is_command() {
    local check_command="$1"
    command -v "${check_command}" >/dev/null 2>&1
}

echo "Проверка наличия необходимых пакетов:"
source /etc/os-release

# проверка пакетов по ID и ID_LIKE в /etc/os-release
if [[ "$ID_LIKE" == *"debian"* ]] || [[ "$ID" == "ubuntu" || "$ID" == "debian" ]]; then
    PKGS=("docker" "bash" "uuid" "ping" "curl" "wget" "netcat" "cron" "openssl")
    INSTALLED_PKGS=$(dpkg --list)
elif [[ "$ID_LIKE" == *"rhel"* ]] || [[ "$ID" == "fedora" || "$ID" == "rhel" || "$ID" == "centos" ]]; then
    PKGS=("docker" "bash" "util-linux" "iputils" "curl" "wget" "netcat|ncat" "cron" "openssl")
    INSTALLED_PKGS=$(yum list --installed)
else
    echo 'Тип ОС не установлен. Проверка наличия пакета в $PATH'
    pkgs=("docker" "bash" "uuidgen" "ping" "curl" "wget" "netcat" "cron")

    set +e
    all_pkgs=""

    for dir in $(echo $PATH | tr ':' '\n'); do
        all_pkgs+=$(ls -m $dir 2>/dev/null | sed 's/,/\n/g' | sed 's/ //g')
    done

    for pkg in "${pkgs[@]}"; do
        pkgs=($(echo "$all_pkgs" | sort | grep -v '^$' | uniq))

        if [[ "${pkgs[*]}" =~ "$pkg" ]]; then
            printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
        else
            printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
            pkg_not_found=1
        fi
    done
    set -e
fi

for pkg in "${PKGS[@]}"; do
    result=$(echo "$INSTALLED_PKGS" | grep -E "$pkg")
    if [[ "$result" != "" ]]; then
        printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
    else
        printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
        pkg_not_found=1
    fi
done

if [[ "$pkg_not_found" -gt 0 ]]; then
    printf "%bНеобходимо установить необходимые пакеты перед первичным запуском приложения! %b\n" "$clr_red" "$clr_rst"
    exit 1
fi

echo "Версии docker:"
docker_version=$(docker version --format '{{.Server.Version}}')
docker_major_version=$(echo "$docker_version" | cut -d '.' -f 1)

if [[ $docker_major_version -lt $docker_engine_min_version ]]; then
    printf "$clr_red\tВерсия docker ($docker_version) меньше минимальной ($min_docker_version) $clr_rst\n"
    exit 1
else
    printf "$clr_grn\tВерсия docker ($docker_version) ОК$clr_rst\n"
fi

compose_system_version=$(docker-compose --version 2>/dev/null | awk '{print $3}' | cut -d',' -f1 | sed 's/v//')
if [[ "$compose_system_version" != "" ]]; then
    compose_system_major_version=$(echo "$compose_system_version" | cut -d '.' -f 1)
    compose_system_minor_version=$(echo "$compose_system_version" | cut -d '.' -f 2)

    if ([[ "$compose_system_major_version" -lt "$docker_compose_min_major_version" ]] || \ 
        [[ "$compose_system_minor_version" -lt "$docker_compose_min_minor_version" ]]); then
        printf "$clr_red\tВерсия системного docker-compose ($compose_system_version) меньше минимальной ($docker_compose_min_major_version.$docker_compose_min_minor_version.0) $clr_rst\n"
    else
        printf "$clr_grn\tВерсия системного docker-compose ($compose_system_version) ОК$clr_rst\n"
    fi
fi

compose_manual_version=$(docker compose version 2>/dev/null | awk '{print $4}' | cut -d',' -f1 | sed 's/v//')
if [[ "$compose_manual_version" != "" ]]; then
    compose_manual_major_version=$(echo "$compose_manual_version" | cut -d '.' -f 1)
    compose_manual_minor_version=$(echo "$compose_manual_version" | cut -d '.' -f 2)

    if ([[ "$compose_manual_major_version" -lt "$docker_compose_min_major_version" ]] || \
        [[ "$compose_manual_minor_version" -lt "$docker_compose_min_minor_version" ]]); then
        printf "$clr_red\tВерсия docker compose (%d) меньше минимальной (%d.%d.0) $clr_rst\n" "$compose_manual_version" "$docker_compose_min_major_version" "$docker_compose_min_minor_version"
    else
        printf "$clr_grn\tВерсия docker compose ($compose_manual_version) ОК$clr_rst\n"
    fi
fi
########################################################################################################################

############# доступность облачных микросервисов HRlink Cloud ##########################################################
echo "Доступность облачных микросервисов:"
urls1=(
    "license.hr-link.ru"
    "pinboard.hr-link.ru"
    "hrlk.ru"
    "pechkin.hr-link.ru"
    "esa.hr-link.ru"
    "trudvsem.hr-link.ru"
)
urls2=(
    "zorro.hr-link.ru"
    "kronos.hr-link.ru"
)

for url in "${urls1[@]}"; do
    out=$(curl -s https://$url/api/v1/version --connect-timeout 5)
    echo -e "\t$url: $out"
done

for url in "${urls2[@]}"; do
    out=$(curl -s https://$url/actuator/info --connect-timeout 5)
    echo -e "\t$url: $out"
done
########################################################################################################################