#!/bin/bash -e

source credentials.txt

CURRENT_VERSION=91

ls docker-compose.yaml > /dev/null 2>&1 || { echo "скрипт нужно запустить из директории с docker-compose.yaml"; exit 4; }

ENV_FILE='.env'
ls "$ENV_FILE" > /dev/null 2>&1 && mv "$ENV_FILE" "$ENV_FILE".bak
touch "$ENV_FILE"

read -p "Введите домен приложения:" domain
[ -z "${domain}" ] && echo "Домен приложения не должен быть пустым." && exit 1

read -p "Введите пользователя хостовой ОС, от которого будут запускаться скрипты cron-задач приложения. Он должен иметь права на чтение и изменение файлов в директории приложения (по ум. root): " cron_user
cron_user="${cron_user:-root}"

# расчет MEM_ALLOC'ов контейнеров приложения в зависимости от количества ОЗУ на сервере
# оставшаяся ОЗУ будет займет ekd-postgresql, ekd-kafka, ekd-ui и ОС хоста
total_memory_kb=$(cat /proc/meminfo | grep -i 'memtotal' | grep -o '[[:digit:]]*')
total_memory_mb=$(($total_memory_kb / 1024))

mem_alloc_monolith=$(($total_memory_mb * 20 / 100)) # ekd-monolith - 20%
mem_alloc_file=$(($total_memory_mb / 10)) # ekd-file - 10%
mem_alloc_file_proc=$(($total_memory_mb * 25 / 100)) # ekd-file-processing - 25%
mem_alloc_other=$(($total_memory_mb * 5 / 100 )) # ekd-api-gateway, ekd-calendar, ekd-repeat-notification, ekd-chat, ekd-showcase - 5% каждый
##########################################################################################


cat<<EOF > "$ENV_FILE"
EKD_KAFKA_VERSION=3.6.2
EKD_POSTGRESQL_VERSION=16-alpine

EKD_UI_VERSION=$CURRENT_VERSION
EKD_MONOLITH_VERSION=$CURRENT_VERSION
EKD_FILE_VERSION=$CURRENT_VERSION
EKD_FILE_PROCESSING_VERSION=$CURRENT_VERSION
EKD_API_GATEWAY_VERSION=90
EKD_CALENDAR_VERSION=$CURRENT_VERSION
EKD_CHAT_VERSION=$CURRENT_VERSION
EKD_REPEAT_NOTIFICATION_VERSION=$CURRENT_VERSION
EKD_SHOWCASE_VERSION=$CURRENT_VERSION
EKD_BUSINESS_JOURNEYS_VERSION=$CURRENT_VERSION
EKD_NEWS_VERSION=$CURRENT_VERSION

CLIENT_DOMAIN='${domain}'
AVAILABLE_HOST='$(echo "${domain}" | grep -Po "\w+\.\K.*.\w+")'
ALLOWED_HOST='$(echo "${domain}" | grep -Po "\w+\K\..*.\w+")'

LICENSE_MANAGER_TOKEN=${LICENSE_MANAGER_TOKEN}

DB_SECRET_KEY='$(head -c 36 /dev/urandom | base64)'
PGDATA="/var/lib/postgresql/data/pgdata"
POSTGRES_DB="postgres"
POSTGRES_HOST="postgresql"
POSTGRES_PORT=5432
POSTGRES_USERNAME="postgres"
POSTGRES_PASSWORD='$(head -c 36 /dev/urandom | base64)'
MIGRATIONS_USER_PASSWORD='$(head -c 36 /dev/urandom | base64)'

OAUTH_SECRET='$(head -c 36 /dev/urandom | base64)'
WEB_SERVER_API_TOKEN='$(head -c 36 /dev/urandom | base64)'
HTTP_SECRET='$(uuidgen)'
PINBOARD_API_TOKEN='1b6a47d6-3adc-47d6-bf13-60f83b9ae7cf'
SESSION_KEYSTORE_PASSWORD='$(uuidgen)'
ZORRO_TOKEN_SECRET_KEY="$(openssl rand -base64 32)"
PECHKIN_TOKEN_SECRET_KEY="$(openssl rand -base64 32)"

KAFKA_HOSTNAME='kafka'
CLUSTER_ID='$(LC_ALL=C tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 16 | base64)'
KAFKA_BROKER_URL=\${KAFKA_HOSTNAME}:9092
NODE_ID=1

MONOLITH_MEM_ALLOC=$mem_alloc_monolith
FILE_PROCESSING_MEM_ALLOC=$mem_alloc_file_proc
FILE_MEM_ALLOC=$mem_alloc_file
API_GATEWAY_MEM_ALLOC=$mem_alloc_other
CALENDAR_MEM_ALLOC=$mem_alloc_other
REPEAT_NOTIFICATION_MEM_ALLOC=$mem_alloc_other
CHAT_MEM_ALLOC=$mem_alloc_other
SHOWCASE_MEM_ALLOC=$mem_alloc_other
BUSINESS_JOURNEYS_MEM_ALLOC=$mem_alloc_other
NEWS_MEM_ALLOC=$mem_alloc_other

FILE_PROCESSING_CREATE_PRINT_FORM_TASK_POOL=$(( $(nproc) / 2 ))
FILE_PROCESSING_CONVERT_PDFA_POOL=$(( $(nproc) * 8 / 10 ))

HRLINK_HOME=$(pwd)
CRON_USER=$cron_user
CRON_HOUR=00
CRON_MINUTE=00
EOF