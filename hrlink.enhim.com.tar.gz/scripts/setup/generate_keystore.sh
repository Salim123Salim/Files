#!/bin/bash

source .env
KEYSTORE_DIR='./ekd-config/keystore'
mkdir -p "$KEYSTORE_DIR"

openssl genrsa -aes256 -out $KEYSTORE_DIR/session.hrlink.key.pem -passout pass:"$SESSION_KEYSTORE_PASSWORD" 2048
openssl req -key $KEYSTORE_DIR/session.hrlink.key.pem -new -sha256 -out $KEYSTORE_DIR/session.hrlink.csr.pem -subj "/CN=session.hrlink" -passin pass:"$SESSION_KEYSTORE_PASSWORD"
openssl x509 -req -in $KEYSTORE_DIR/session.hrlink.csr.pem -signkey $KEYSTORE_DIR/session.hrlink.key.pem -out $KEYSTORE_DIR/session.hrlink.cert.pem -days 36525 -passin pass:"$SESSION_KEYSTORE_PASSWORD"
openssl pkcs12 -export -in $KEYSTORE_DIR/session.hrlink.cert.pem -inkey $KEYSTORE_DIR/session.hrlink.key.pem -name session -out $KEYSTORE_DIR/keystoreSession.p12 -noiter -nomaciter -passin pass:"$SESSION_KEYSTORE_PASSWORD" -passout pass:"$SESSION_KEYSTORE_PASSWORD"