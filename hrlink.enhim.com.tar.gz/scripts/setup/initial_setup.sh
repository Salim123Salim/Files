#!/bin/bash

clr_rst='\033[0m'
clr_red='\033[0;31m'
clr_grn='\033[0;32m'
clr_ylw='\033[1;33m'

docker_registry_setup() {
    read -p "Введите путь до образов HRlink (по ум. docker.hr-link.ru):" docker_registry_link
    
    if [[ -z "$docker_registry_link" ]] || [[ "$docker_registry_link" == "docker.hr-link.ru" ]]; then
        echo "Авторизация в docker.hr-link.ru"
        docker login docker.hr-link.ru --username=$DOCKER_LOGIN --password=$DOCKER_PASS
    else
        echo "Авторизация в $docker_registry_link"
        docker login $docker_registry_link
        echo -e "\n\nDOCKER_NEXUS_LINK=$docker_registry_link" >> .env
    fi
}

bash scripts/setup/check_requirements.sh

source credentials.txt

# создание .env
bash scripts/setup/create_env.sh

# docker registry (кастоиный/дефолтный) и авторизация в нем
docker_registry_setup

# генерация keystore
bash scripts/setup/generate_keystore.sh

# конфигурация SSL
bash scripts/setup/setup_ssl.sh

if [[ "$ROOTLESS_DEPLOYMENT" == "true" ]]; then
    sed -i 's/user: root/#user: root/' docker-compose.yaml
    sed -i 's/user: root/#user: root/' compose.d/template.yaml

    mkdir -p logs/{ekd-monolith,ekd-file,ekd-file-processing,ekd-api-gateway,ekd-calendar,ekd-chat,ekd-news,ekd-repeat-notification,ekd-showcase,ekd-business-journeys}
    mkdir -p ekd_kafka/{1,logs}
    mkdir -p postgresql-data/pgdata

    printf "%bПрименение прав директориям приложения (необходим root)%b\n" "$clr_ylw" "$clr_rst"

    sudo chown -R 1186:1186 logs/ ekd-monolith-storage/ ekd-config/keystore/
    sudo chown -R 1001:1001 ekd_kafka/
    sudo chown -R 70:70 postgresql-data/
fi

# запуск приложения
docker compose pull || docker-compose pull
docker compose up -d || docker-compose up -d

# HRLINK_HOME
test -w /etc/environment && DEST='/etc/environment' || DEST="$HOME/.profile"
echo "HRLINK_HOME=$(pwd)" >> "$DEST"
echo "HRLINK_HOME=$(pwd) добавлен в $DEST"

sleep 5

# cron
echo "Установка файла регулярных задач в /etc/cron.d/"
sudo ln -sf "$(pwd)/scripts/cron/crontab" /etc/cron.d/hrlink

printf "\n$clr_grnГотово$clr_rst\n"
