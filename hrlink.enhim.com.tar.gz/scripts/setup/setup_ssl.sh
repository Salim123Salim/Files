#!/bin/bash

clr_rst='\033[0m'
clr_red='\033[0;31m'
clr_grn='\033[0;32m'

read_cert() {
    local pem=""
    while IFS= read -r line; do
        pem+="$line"$'\n'
        [[ $line == "-----END CERTIFICATE-----" ]] && break
    done
    printf '%s' "$pem"
}

leaf() {
    echo "Вставьте LEAF сертификат (заканчивается с -----END CERTIFICATE-----):"
    leaf=$(read_cert)

    if openssl x509 -noout -text <<< "$leaf" | grep -q "CA:TRUE"; then
        printf "%b\tВведен не LEAF сертитфикат%b\n" "$clr_red" "$clr_rst"
        leaf
    fi
}

intermediate() {
    leaf_issuer=$(openssl x509 -noout -issuer -nameopt RFC2253 <<< "$leaf" | sed 's/issuer=//g')

    echo "Встаьте промежуточный сертификат:"
    inter=$(read_cert)

    if ! openssl x509 -noout -text <<<"$inter" | grep -q "CA:TRUE"; then
        printf "%b\tЭтот промежуточный сертификат выпущен не публичным УЦ%b\n" "$clr_red" "$clr_rst"
        intermediate
    fi
    inter_subject=$(openssl x509 -noout -subject -nameopt RFC2253 <<<"$inter" | sed 's/subject=//g')
    inter_issuer=$(openssl x509 -noout -issuer -nameopt RFC2253 <<<"$inter" | sed 's/issuer=//g')

    if [[ "$leaf_issuer" != "$inter_subject" ]]; then
        printf "%b\tЭтот сертификат не является промежуточным для данного сертификата%b\n" "$clr_red" "$clr_rst"
        intermediate
    fi
    if [[ "$inter_subject" == "$inter_issuer" ]]; then
        printf "%b\tЭтот сертификат не является промежуточным%b\n" "$clr_red" "$clr_rst"
        intermediate
    fi
}

root() {
    echo "Вставьте root сертитфикат:"
    root=$(read_cert)

    root_subject=$(openssl x509 -noout -subject -nameopt RFC2253 <<<"$root" | sed 's/subject=//g')
    root_issuer=$(openssl x509 -noout -issuer  -nameopt RFC2253 <<<"$root" | sed 's/issuer=//g')

    if ! openssl x509 -noout -text <<<"$root" | grep -q "CA:TRUE"; then
        printf "%b\tЭтот сертификат выпущен не публичным УЦ%b\n" "$clr_red" "$clr_rst"
        root
    fi

    if [[ "$root_subject" != "$root_issuer" ]]; then
        printf "%b\tКорневой сертификат не подписывает себя%b\n" "$clr_red" "$clr_rst"
        root
    fi
    if [[ "$inter_issuer" != "$root_subject" ]]; then
        printf "%b\tКорневой сертификат не подписывает промежуточный%b\n" "$clr_red" "$clr_rst"
        root
    fi
}

private_key() {
    while true; do
        read -rp "Цепочка сертификатов запаролена? [y/N]: " reply
        echo
        case "$reply" in
            [Yy])
                local key=""
                while IFS= read -r line; do
                    key+="$line"$'\n'
                    [[ $line == "-----END PRIVATE KEY-----" ]] && break
                done
                printf "%s\n" "$key" > "certs/cert.key"
                break
                ;;
            [Nn]|"")
                sed -i '51 s/^/#/' nginx.conf
                break
                ;;
            *)
                echo "Введите y (yes) или n (no)"
                ;;
        esac
    done
}

setup_ssl() {
    out_file="certs/cert.pem"

    leaf
    intermediate
    root

    printf '%s\n' "$leaf" >"$out_file"
    printf '%s\n' "$inter" >>"$out_file"
    printf '%s\n' "$root" >>"$out_file"

    printf "%b\tЦепочка сертификатов собрана успешно%b\n" "$clr_grn" "$clr_rst"
    private_key
}

while true; do
    read -rp "Терминирование SSL будет происходить в приложении? [y/N]: " reply
    echo
    case "$reply" in
        [Yy])
            setup_ssl
            break
            ;;
        [Nn]|"")
            sed -i '42,57 s/^/#/' nginx.conf
            echo "Терминация SSL отключена"
            break
            ;;
        *)
            echo "Введите y (yes) или n (no)"
            ;;
    esac
done

printf "%b\tЦепочка сертификатов собрана успешно%b\n" "$clr_grn" "$clr_rst"
