#!/bin/bash

date_filter='%Y-%m-%d_%H-%M-%S'

NEW_RELEASE=79
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +$date_filter)"
UPDATE_LOG_FILE="logs/updates/$NEW_RELEASE.txt"

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

pre_update_checks() {
    ls docker-compose.yaml .env > /dev/null 2>&1 || { echo "скрипт необходимо запустить из директории с docker-compose.yaml и .env"; exit 4; }

    is_command() {
        local check_command="$1"
        command -v "${check_command}" >/dev/null 2>&1
    }

    echo "Проверка наличия необходимых пакетов:"
    pkgs=("docker" "bash" "uuidgen" "ping" "curl" "wget" "netcat" "cron" "Aass")

    for pkg in "${pkgs[@]}"; do
        is_command "$pkg"
        exit_code="$?"

        if [[ $exit_code -eq 0 ]]; then
            printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
        else
            printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
            pkg_not_found=1
        fi
    done

    if [[ "$pkg_not_found" -gt 0 ]]; then
        printf "%bНеобходимо установить необходимые пакеты перед обновлением! %b\n" "$clr_red" "$clr_rst"
        exit 1
    fi
}

pre_update_actions() {
    echo "Директория бекапа до обновления - $BACKUP_DIR"
    mkdir -p $BACKUP_DIR
    mkdir -p logs/updates
    touch $UPDATE_LOG_FILE

    cp docker-compose.yaml nginx.conf .env ekd-config/custom.conf $BACKUP_DIR
    cp ekd-config/ekd-file/custom.conf $BACKUP_DIR/ekd-file-custom.conf
}

db_actions() {
    curr_version="$(grep '/postgres:' docker-compose.yaml | head -n 1 | awk -F: '{print $NF}')"
    if [[ -n "$(docker container ls --format 'table {{.Names}}' 2>/dev/null | grep 'ekd-postgresql')" ]]; then
        databases=$(docker exec ekd-postgresql psql -U postgres -A -t -c "SELECT datname FROM pg_database;")
        mapfile -t db_array <<< "$databases"

        echo "Реиндексация БД и переключение postgres:$curr_version на postgres:13-alpine"
        echo "$(date +$date_filter): переключение postgres:$curr_version на postgres:13-alpine" >> $UPDATE_LOG_FILE

        read -p "Остановить приложение? [y/N]: " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            docker compose down || docker-compose down
        else
            echo "Обновление отменено"
            echo "$(date +$date_filter): Обновление отменено" >> $UPDATE_LOG_FILE 2>&1
            exit 2
        fi
        sed -i "s/postgres:$curr_version/postgres:13-alpine/" docker-compose.yaml
        docker compose up -d postgresql || docker-compose up -d postgresql
        sleep 5
        for db in "${db_array[@]}"; do
            echo "$(date +$date_filter): реиндекс бд $db"
            docker exec --user postgres ekd-postgresql reindexdb --concurrently -d "$db" -j 15 -e | awk '{print "\t" $0}'
        done >> $UPDATE_LOG_FILE 2>&1
        echo "Реиндекс баз закончен"
    else
        echo "$(date +$date_filter): контейнер ekd-postgresql не найден" >> $UPDATE_LOG_FILE
        printf "$clr_ylwКонтейнер ekd-postgresql не найден на этом сервере.\nНеобходимо исполнить скрипт reindex_db.sh на сервере с контейнером БД.$clr_rst\n"
    fi
}

configs_actions() {
    echo "$(date +$date_filter): обновление версий контейнеров"

    set -x
    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" .env

    echo "$(date +$date_filter): добавление настроек демонов ЛНА"
    cat<<EOF >> ekd-config/custom.conf
# настройки демонов ЛНА
daemons.caDocumentSigningRequest.maximumPoolSize = 10
daemons.caDocumentSigningSmsConfirmation.maximumPoolSize = 10
daemons.normativeActSendToSigningTaskDaemon.pauseDurationBetweenPacks = 30 s
daemons.normativeActSendToSigningTaskDaemon.maximumPoolSize = 2
EOF

    # применение пересмотренных MEM_ALLOC'ов контейнеров
    echo "$(date +$date_filter): применение пересмотренных MEM_ALLOC'ов контейнеров"
    OLD_MONOLITH_MEM_ALLOC=$(grep '  ekd-monolith:' docker-compose.yaml -A 15 | grep MEM_ALLOC | awk '{print $2}')
    OLD_FILE_PROCESSING_MEM_ALLOC=$(grep 'ekd_file_processing_db' docker-compose.yaml -A 15 | grep MEM_ALLOC | awk '{print $2}')

    if [[ "$OLD_MONOLITH_MEM_ALLOC" == "\${MONOLITH_MEM_ALLOC}" ]] || [[ "$OLD_MONOLITH_MEM_ALLOC" -lt 2000 ]]; then
        MONOLITH_MEM_ALLOC=2000
    else
        MONOLITH_MEM_ALLOC=$OLD_MONOLITH_MEM_ALLOC
    fi

    if [[ "$FILE_PROCESSING_MEM_ALLOC" == "\${FILE_PROCESSING_MEM_ALLOC}" ]] || [[ "$FILE_PROCESSING_MEM_ALLOC" -lt 3000 ]]; then
        FILE_PROCESSING_MEM_ALLOC=3000
    else
        FILE_PROCESSING_MEM_ALLOC=$OLD_FILE_PROCESSING_MEM_ALLOC
    fi

    sed -i '/MEM_ALLOC:/d' docker-compose.yaml

    sed -i '/SERVICE_JMX_PORT: 8990/a\      MEM_ALLOC: ${MONOLITH_MEM_ALLOC}' docker-compose.yaml
    sed -i '/POSTGRES_DBNAME: ekd_file\([^_]\|$\)/a\      MEM_ALLOC: ${FILE_MEM_ALLOC}' docker-compose.yaml
    sed -i '/POSTGRES_DBNAME: ekd_file_processing_db/a\      MEM_ALLOC: ${FILE_PROCESSING_MEM_ALLOC}' docker-compose.yaml
    sed -i '/CORS_ALLOWED_HOSTS: "https:\/\/${CLIENT_DOMAIN}"/a\      MEM_ALLOC: ${API_GATEWAY_MEM_ALLOC}' docker-compose.yaml
    sed -i '/POSTGRES_DBNAME: ekd_calendar_db/a\      MEM_ALLOC: ${CALENDAR_MEM_ALLOC}' docker-compose.yaml
    sed -i '/POSTGRES_DBNAME: ekd_chat_db/a\      MEM_ALLOC: ${CHAT_MEM_ALLOC}' docker-compose.yaml
    sed -i '/POSTGRES_DBNAME: ekd_repeat_notification_db/a\      MEM_ALLOC: ${REPEAT_NOTIFICATION_MEM_ALLOC}' docker-compose.yaml
    sed -i '/POSTGRES_DBNAME: ekd_showcase_db/a\      MEM_ALLOC: ${SHOWCASE_MEM_ALLOC}' docker-compose.yaml

    sed -i '/.*_MEM_ALLOC=/d' .env

    echo "" >> .env
    echo "MONOLITH_MEM_ALLOC=${MONOLITH_MEM_ALLOC}" >> .env
    echo "FILE_MEM_ALLOC=1000" >> .env
    echo "FILE_PROCESSING_MEM_ALLOC=${FILE_PROCESSING_MEM_ALLOC}" >> .env
    echo "API_GATEWAY_MEM_ALLOC=500" >> .env
    echo "CALENDAR_MEM_ALLOC=500" >> .env
    echo "CHAT_MEM_ALLOC=500" >> .env
    echo "REPEAT_NOTIFICATION_MEM_ALLOC=500" >> .env
    echo "SHOWCASE_MEM_ALLOC=500" >> .env

    set +x
} >> $UPDATE_LOG_FILE 2>&1

pull_images() {
    echo "Cкачиваем новые образы приложения"
    docker compose pull || docker-compose pull
    echo "Удаляем старые образы"
    docker system prune -af --filter "until=$((14*24))h" | grep "Total reclaimed space:"
}

restart_app() {
    read -p "Перезапустить приложение? [y/N]: " -n 1 -r
    echo
    if [[ $REPLY =~ ^[YyНн]$ ]]; then
        docker compose up -d || docker-compose up -d
    else
        echo "Перезапуск отменен"
        exit 2
    fi
}

post_update() {
    echo "Установка регулярных задач в cron"
    echo "Текущее время системы - $(date)"
    read -p "Введите время в которое ежедневно получать и устанавливать хотфиксы приложения (по ум. 03:00): " time
    time="${time:-03:00}"
    if [[ ! "$time" =~ ^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$ ]]; then
        echo "Введенное время некорректно. Используется значение по умолчанию: 03:00"
        time="03:00"
    fi
    IFS=":" read -r hour minute <<< "$time"
    CRON_JOBS=(
        "$minute $hour * * * cd $HRLINK_HOME && (docker compose pull || docker-compose pull) && (docker compose up -d || docker-compose up -d)"
        '00 00 * * 0 docker system prune -af --filter "until=7d"'
    )

    if ! systemctl is-active --quiet cron; then
        printf "%bСлужба cron не запущена. Запустите её с помощью 'sudo systemctl start cron'%b\n" "$clr_red" "$clr_rst"
        printf "%bПосле запуска добавьте следующие записи в crontab текущего пользователя:%b\n" "$clr_ylw" "$clr_rst"
        for job in "${CRON_JOBS[@]}"; do echo "$job"; done
    fi

    log "Удаление старых записей"
    (crontab -l | grep -v -F "(docker compose pull || docker-compose pull)") | crontab -
    (crontab -l | grep -v -F "docker system prune -af") | crontab -

    for job in "${CRON_JOBS[@]}"; do
        echo "Добавление записи: $job"
        (crontab -l 2>/dev/null | grep -v -F "$job" || true; echo "$job") | crontab -
    done
}

pre_update_checks
pre_update_actions
db_actions
configs_actions
pull_images
restart_app
post_update

printf "$clr_grnГотово$clr_rst\n"
