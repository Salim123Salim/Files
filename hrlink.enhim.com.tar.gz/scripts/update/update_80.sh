#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

NEW_RELEASE=80
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d:%H-%M-%S)"
UPDATE_LOG_FILE="logs/updates/$NEW_RELEASE.txt"

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

log() {
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1"
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1" >> $UPDATE_LOG_FILE
}

pre_update_checks() {
    ls docker-compose.yaml .env > /dev/null 2>&1 || { echo "скрипт необходимо запустить из директории с docker-compose.yaml и .env"; exit 4; }

    CURR_RELEASE=$(grep EKD_MONOLITH_VERSION .env | cut -d'=' -f2)
    if (( "$NEW_RELEASE" - "$CURR_RELEASE" != 1 )); then
        printf "%b\tПеред установкой релиза %b необходимо установить предыдущие релизы (установленный релиз - %b)%b\n" "$clr_red" "$NEW_RELEASE" "$CURR_RELEASE" "$clr_rst"
        exit 1
    fi

    if (( "$NEW_RELEASE" - "$CURR_RELEASE" == 0 )); then
        printf "%b\tУже установлен релиз %b%b\n" "$clr_red" "$CURR_RELEASE" "$clr_rst"
        exit 1
    fi

    echo "Проверка наличия необходимых пакетов:"

    set +u
    source /etc/os-release
    pkg_not_found=0

    # проверка пакетов по ID и ID_LIKE в /etc/os-release
    if [[ "$ID_LIKE" == *"debian"* ]] || [[ "$ID" == "ubuntu" || "$ID" == "debian" ]]; then
        PKGS=("docker" "bash" "uuid" "ping" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(dpkg --list)
    elif [[ "$ID_LIKE" == *"rhel"* ]] || [[ "$ID" == "fedora" || "$ID" == "rhel" || "$ID" == "centos" ]]; then
        PKGS=("docker" "bash" "util-linux" "iputils" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(yum list --installed)
    else
        echo 'Тип ОС не усстановлен. Проверка наличия пакета в $PATH'
        is_command() {
            local check_command="$1"
            command -v "${check_command}" >/dev/null 2>&1
        }

        pkgs=("docker" "bash" "uuidgen" "ping" "curl" "wget" "netcat" "cron")

        for pkg in "${pkgs[@]}"; do
            is_command "$pkg"
            exit_code="$?"

            if [[ $exit_code -eq 0 ]]; then
                printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
            else
                printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
                pkg_not_found=1
            fi
        done
    fi

    for pkg in "${PKGS[@]}"; do
        result=$(echo "$INSTALLED_PKGS" | grep -E "$pkg")
        if [[ "$result" != "" ]]; then
            printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
        else
            printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
            pkg_not_found=1
        fi
    done

    if [[ "$pkg_not_found" -gt 0 ]]; then
        printf "%bНеобходимо установить необходимые пакеты перед обновлением! %b\n" "$clr_red" "$clr_rst"
        exit 1
    fi
    set -u
}

pre_update_actions() {
    mkdir -p "$BACKUP_DIR"
    echo "Директория бекапа до обновления - $BACKUP_DIR"
    mkdir -p "logs/updates"
    touch "$UPDATE_LOG_FILE"

    cp docker-compose.yaml nginx.conf .env ekd-config/custom.conf "$BACKUP_DIR"
    cp ekd-config/ekd-file/custom.conf "$BACKUP_DIR/ekd-file-custom.conf"
}

db_actions() {
    if [[ -n "$(docker container ls --format 'table {{.Names}}' 2>/dev/null | grep 'ekd-postgresql')" ]]; then
        source .env
        docker exec --user postgres ekd-postgresql psql -U postgres -c "ALTER USER postgres WITH PASSWORD '$POSTGRES_PASSWORD'"
    fi
}

configs_actions() {
    log "обновление версий контейнеров"

    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" .env

    # BROKER_ID -> NODE_ID (kafka)
    sed -i 's/BROKER_ID/NODE_ID/' .env
    sed -i 's/BROKER_ID/NODE_ID/g' docker-compose.yaml

    # добавление hostname'ов контейнерам
    sed -i '/^\s*container_name:/ {h;s/^\s*container_name:\s*\(.*\)/    hostname: \1/;x;G;}' docker-compose.yaml
    sed -i 's/hostname: ekd_kafka/hostname: kafka/' docker-compose.yaml
    sed -i 's/hostname: ekd-postgresql/hostname: postgresql/' docker-compose.yaml

    # перенос networks над services
    SUBNET=$(sed -n '/^networks:/,/^$/p' docker-compose.yaml | grep 'subnet:' | awk '{print $3}')
    sed -i -e '/^networks:/,/^$/d' -e "/^services:/i\
networks:\n\
  default:\n\
    driver: bridge\n\
    ipam:\n\
      config:\n\
        - subnet: ${SUBNET}\n" docker-compose.yaml

    # добавление контейнера ekd-charon
    cat<<EOF >> docker-compose.yaml
  ekd-charon:
    <<: [ *base ]
    container_name: ekd-charon
    image: \${DOCKER_NEXUS_LINK:-docker.hr-link.ru}/ekd/ekd-charon:latest
    volumes:
      - ./scripts/:/local/:rw,z

EOF
    sed -i 's#- ./postgresql-init/#- ./scripts/postgresql/#' docker-compose.yaml

    # настройка и генерация keystore для qr-кодов моб. приложения
    if [[ -z $(grep SESSION_KEYSTORE_PASSWORD docker-compose.yaml) ]]; then
        KEYSTORE_DIR='./ekd-config/keystore'
        mkdir -p "$KEYSTORE_DIR"
        SESSION_KEYSTORE_PASSWORD=$(uuidgen)

        openssl genrsa -aes256 -out $KEYSTORE_DIR/session.hrlink.key.pem -passout pass:"$SESSION_KEYSTORE_PASSWORD" 2048
        openssl req -key $KEYSTORE_DIR/session.hrlink.key.pem -new -sha256 -out $KEYSTORE_DIR/session.hrlink.csr.pem -subj "/CN=session.hrlink" -passin pass:"$SESSION_KEYSTORE_PASSWORD"
        openssl x509 -req -in $KEYSTORE_DIR/session.hrlink.csr.pem -signkey $KEYSTORE_DIR/session.hrlink.key.pem -out $KEYSTORE_DIR/session.hrlink.cert.pem -days 36525 -passin pass:"$SESSION_KEYSTORE_PASSWORD"
        openssl pkcs12 -export -in $KEYSTORE_DIR/session.hrlink.cert.pem -inkey $KEYSTORE_DIR/session.hrlink.key.pem -name session -out $KEYSTORE_DIR/keystoreSession.p12 -noiter -nomaciter -passin pass:"$SESSION_KEYSTORE_PASSWORD" -passout pass:"$SESSION_KEYSTORE_PASSWORD"

        echo >> .env
        echo "SESSION_KEYSTORE_PASSWORD=$SESSION_KEYSTORE_PASSWORD" >> .env
        sed -i "\|./Aspose.Total.Java.lic:/var/hrlink/licenses/Aspose.Total.Java.lic:ro,z|i\      - $KEYSTORE_DIR/keystoreSession.p12:/var/hrlink/running_instance/ekd-monolith/conf/keystoreSession.p12:ro,z" docker-compose.yaml
    fi

    # настройки пулов ekd-file-processing
    CREATE_PF_POOL="$(( $(nproc) / 2 ))"
    PDFA_POOL="$(( $(nproc) * 8 / 10 ))"
    echo >> .env
    echo "FILE_PROCESSING_CREATE_PRINT_FORM_TASK_POOL=$CREATE_PF_POOL" >> .env
    echo "FILE_PROCESSING_CONVERT_PDFA_POOL=$PDFA_POOL" >> .env

    # удаление блоков depends_on и links
    sed -i '/^\s*links:/,/^\s*\S/ { /^\s*links:/,/^\s*\S/d }' docker-compose.yaml && sed -i '/^\s*- postgresql:postgresql/d' docker-compose.yaml
    sed -i -E '/^[[:space:]]+depends_on:/,/^[[:space:]]*$/{/^ *depends_on:/d; /^ *- /d}' docker-compose.yaml

    # удаление маунта лицензии Aspose из монолита
    sed -i '/^\s*-\s*\.\/Aspose.Total.Java.lic:/d' docker-compose.yaml

    # удаление ekd-monolith-storage у монолита
    sed -i '/^\s*- \.\/ekd-monolith-storage:\/var\/hrlink\/tmp\/storage:rw,z$/d' docker-compose.yaml

    # якорь env ekd-monolith и удаление ports:
    sed -i '/ekd-monolith:/,/^\s*$/ {
    /environment:/,/- 8000:8000/ {
        /^environment:/!{
            /^ports:/!d
        }
    }
    /image:/a\
    environment:\
        <<: [ *base-env, *monolith-env ]
}' docker-compose.yaml
    sed -i '/^networks:/i\
x-monolith-env: &monolith-env\
    SERVICE_NAME: ekd-monolith\
    SERVICE_PORT: 8000\
    SERVICE_DEBUG_PORT: 8900\
    SERVICE_JMX_PORT: 8990\
    MEM_ALLOC: ${MONOLITH_MEM_ALLOC}\
    SESSION_KEYSTORE_ALIAS: session\
    SESSION_KEYSTORE_PATH: /var/hrlink/running_instance/ekd-monolith/conf/keystoreSession.p12\
    SESSION_KEYSTORE_PASSWORD: ${SESSION_KEYSTORE_PASSWORD}\
    OAUTH_SECRET: ${OAUTH_SECRET}\
    OMNIDESK_ADMIN_LOGIN_EMAIL: ${OMNIDESK_ADMIN_LOGIN_EMAIL}\
    OMNIDESK_API_KEY: ${OMNIDESK_API_KEY}\
    PINBOARD_API_TOKEN: ${PINBOARD_API_TOKEN}\
    EKD_CHAT_TOKEN: Configured ${WEB_SERVER_API_TOKEN}\
    EKD_SHOWCASE_TOKEN: Configured ${WEB_SERVER_API_TOKEN}\
    EKD_FILE_PROCESSING_TOKEN: ${WEB_SERVER_API_TOKEN}\
    SHARED_FILE_API_TOKEN: ${LICENSE_MANAGER_TOKEN}\
' docker-compose.yaml
    # якорь env ekd-file-processing
    sed -i '/ekd-file-processing:/,/^\s*$/ {
    /environment:/,/volumes:/ {
        /^environment:/!{
            /^volumes:/!d
        }
    }
    /image:/a\
    environment:\
        <<: [ *base-env, *file-processing-env ]\
    volumes:
}' docker-compose.yaml
    sed -i '/^networks:/i\
x-file-proc-env: &file-processing-env\
    POSTGRES_DBNAME: ekd_file_processing_db\
    MEM_ALLOC: ${FILE_PROCESSING_MEM_ALLOC}\
    SHARED_FILE_HOST: https://license.hr-link.ru/shared-file\
    SHARED_FILE_API_TOKEN: ${LICENSE_MANAGER_TOKEN}\
    EKD_FILE_URL: http://ekd-file:8000\
    EKD_FILE_API_TOKEN: ${WEB_SERVER_API_TOKEN}\
    EKD_METADATA_URL: http://ekd-monolith:8000\
    EKD_METADATA_API_TOKEN: Configured ${WEB_SERVER_API_TOKEN}\
    CLOUD_FILE_PROCESSING_ENABLED: false\
    INSTANCE_RESET_TIMEOUT: 30s\
    INSTANCE_LOCK_RESET_TIMEOUT: 30s\
    SCHEDULE_CONVERT_FILE_TO_PDFA_TASK_TASK_PRIORITIZATION_ENABLED: true\
    SCHEDULE_CREATE_PRINT_FORM_TASK_TASK_PRIORITIZATION_ENABLED: true\
    SCHEDULE_CREATE_PRINT_FORM_TASK_MAXIMUM_POOL_SIZE: ${FILE_PROCESSING_CREATE_PRINT_FORM_TASK_POOL}\
    SCHEDULE_CONVERT_FILE_TO_PDFA_TASK_MAXIMUM_POOL_SIZE: ${FILE_PROCESSING_CONVERT_PDFA_POOL}\
' docker-compose.yaml

} >> $UPDATE_LOG_FILE 2>&1

pull_images() {
    log "Cкачиваем новые образы приложения"
    docker compose pull || docker-compose pull
    log "Удаляем старые образы"
    docker system prune -af --filter "until=$((24*5))h" | grep "Total reclaimed space:"
}

restart_app() {
    read -p "Перезапустить приложение? [y/N]: " -n 1 -r
    echo
    if [[ $REPLY =~ ^[YyНн]$ ]]; then
        docker compose up -d || docker-compose up -d
    else
        echo "Перезапуск отменен"
        exit 2
    fi
}

post_update() {
    echo "Установка регулярных задач в cron"
    echo "Текущее время системы - $(date)"
    read -p "Введите время в которое ежедневно получать и устанавливать хотфиксы приложения (по ум. 03:00): " time
    time="${time:-03:00}"
    if [[ ! "$time" =~ ^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$ ]]; then
        echo "Введенное время некорректно. Используется значение по умолчанию: 03:00"
        time="03:00"
    fi
    IFS=":" read -r hour minute <<< "$time"
    HRLINK_HOME=$(pwd)
    CRON_JOBS=(
        "$minute $hour * * * cd $HRLINK_HOME && (docker compose pull || docker-compose pull) && (docker compose up -d || docker-compose up -d)"
        '00 00 * * * docker system prune -af --filter "until=$((24*5))h"'
    )

    if ! systemctl is-active --quiet cron; then
        printf "%bСлужба cron не запущена. Запустите её с помощью 'sudo systemctl start cron'%b\n" "$clr_red" "$clr_rst"
        printf "%bПосле запуска добавьте следующие записи в crontab текущего пользователя:%b\n" "$clr_ylw" "$clr_rst"
        for job in "${CRON_JOBS[@]}"; do echo "$job"; done
    fi

    set +o pipefail
    log "Удаление старых записей"
    (crontab -l | grep -v -F "(docker compose pull || docker-compose pull)") | crontab -
    (crontab -l | grep -v -F "docker system prune -af") | crontab -

    for job in "${CRON_JOBS[@]}"; do
        echo "Добавление записи: $job"
        (crontab -l 2>/dev/null | grep -v -F "$job" || true; echo "$job") | crontab -
    done
    set -o pipefail
}

pre_update_checks
pre_update_actions
db_actions
configs_actions
pull_images
restart_app
post_update

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
