#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="3"

NEW_RELEASE=85
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d:%H-%M-%S)"
UPDATE_LOG_FILE="logs/updates/$NEW_RELEASE.txt"
TMP_DIR=$(mktemp -d)

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

log() {
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1"
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1" >> $UPDATE_LOG_FILE
}

pre_update_checks() {
    ls docker-compose.yaml .env > /dev/null 2>&1 || { echo "скрипт необходимо запустить из директории с docker-compose.yaml и .env"; exit 4; }

    CURR_RELEASE=$(grep EKD_MONOLITH_VERSION .env | cut -d'=' -f2)
    if (( "$NEW_RELEASE" - "$CURR_RELEASE" != 1 )); then
        printf "%b\tПеред установкой релиза %b необходимо установить предыдущие релизы (установленный релиз - %b)%b\n" "$clr_red" "$NEW_RELEASE" "$CURR_RELEASE" "$clr_rst"
        exit 1
    fi

    if (( "$NEW_RELEASE" - "$CURR_RELEASE" == 0 )); then
        printf "%b\tУже установлен релиз %b%b\n" "$clr_red" "$CURR_RELEASE" "$clr_rst"
        exit 1
    fi

    echo "Проверка наличия необходимых пакетов:"

    set +u
    source /etc/os-release
    pkg_not_found=0

    # проверка пакетов по ID и ID_LIKE в /etc/os-release
    if [[ "$ID_LIKE" == *"debian"* ]] || [[ "$ID" == "ubuntu" || "$ID" == "debian" ]]; then
        PKGS=("docker" "bash" "uuid" "ping" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(dpkg --list)
    elif [[ "$ID_LIKE" == *"rhel"* ]] || [[ "$ID" == "fedora" || "$ID" == "rhel" || "$ID" == "centos" ]]; then
        PKGS=("docker" "bash" "util-linux" "iputils" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(yum list --installed)
    else
        echo 'Тип ОС не установлен. Проверка наличия пакета в $PATH'
        pkgs=("docker" "bash" "uuidgen" "ping" "curl" "wget" "netcat" "cron")

        set +e
        all_pkgs=""

        for dir in $(echo $PATH | tr ':' '\n'); do
            all_pkgs+=$(ls -m $dir 2>/dev/null | sed 's/,/\n/g' | sed 's/ //g')
        done

        for pkg in "${pkgs[@]}"; do
            pkgs=($(echo "$all_pkgs" | sort | grep -v '^$' | uniq))

            if [[ "${pkgs[*]}" =~ "$pkg" ]]; then
                printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
            else
                printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
                pkg_not_found=1
            fi
        done
        set -e
    fi

    for pkg in "${PKGS[@]}"; do
        result=$(echo "$INSTALLED_PKGS" | grep -E "$pkg")
        if [[ "$result" != "" ]]; then
            printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
        else
            printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
            pkg_not_found=1
        fi
    done

    if [[ "$pkg_not_found" -gt 0 ]]; then
        printf "%bНеобходимо установить необходимые пакеты перед обновлением! %b\n" "$clr_red" "$clr_rst"
        exit 1
    fi
    set -u

    # наличие свободного места
    disks=("/" "/var")
    echo
    for disk in "${disks[@]}"; do
        disk_space=$(df $disk --output=avail -x loop -x tmpfs | tail -n 1 | awk '{print int($1 / 1024 / 1024)}')
        if [[ $disk_space -lt 10 ]]; then
            printf "\t%bНа $disk недостаточно места ($disk_space). Для обновления необходимо 10ГБ.%b\n" "$clr_red" "$disk_space" "$clr_rst"
        else
            printf "\t%b$disk\tOK (%d GB free) %b\n" "$clr_grn" "$disk_space" "$clr_rst"
        fi
    done

    # наличие прав на чтение и изменение конфигов
    files=(".env" "docker-compose.yaml" "nginx.conf" "ekd-config/custom.conf" "ekd-config/ekd-file/custom.conf")
    rw_files_count="${#files[@]}"
    for file in "${files[@]}"; do
        if ! ([[ -w $file ]] && [[ -r $file ]]); then
            printf "\t%b%b%b\n" "$clr_red" "Невозможно редактирование $file!" "$clr_rst"
            ((rw_files_count--))
        fi
    done

    if [[ $rw_files_count -lt "${#files[@]}" ]]; then
        exit 1
    fi
}

pre_update_actions() {
    mkdir -p "$BACKUP_DIR"
    echo "Директория бекапа до обновления - $BACKUP_DIR"
    mkdir -p "logs/updates"
    touch "$UPDATE_LOG_FILE"

    mkdir -p "$TMP_DIR/ekd-config/ekd-file/"

    cp docker-compose.yaml nginx.conf .env ekd-config/custom.conf "$BACKUP_DIR"
    cp ekd-config/ekd-file/custom.conf "$BACKUP_DIR/ekd-file-custom.conf"

    cp .env docker-compose.yaml nginx.conf "$TMP_DIR"
    cp ekd-config/custom.conf "$TMP_DIR/ekd-config/custom.conf"
    cp ekd-config/ekd-file/custom.conf "$TMP_DIR/ekd-config/ekd-file/custom.conf"
}

db_actions() {
    docker exec ekd-charon bash -c 'PGPASSWORD=$POSTGRES_PASSWORD psql -h $POSTGRES_HOST --dbname postgres -U $POSTGRES_USERNAME -c "CREATE DATABASE ekd_request_logger"'
    docker exec ekd-charon bash -c 'PGPASSWORD=$POSTGRES_PASSWORD psql -h $POSTGRES_HOST --dbname postgres -U $POSTGRES_USERNAME -c "CREATE DATABASE ekd_notification"'
}

configs_actions() {
    log "обновление версий контейнеров"

    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_NEWS_VERSION=.*/EKD_NEWS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_BUSINESS_JOURNEYS_VERSION=.*/EKD_BUSINESS_JOURNEYS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"

    if [[ "$(grep x-extra-hosts "$TMP_DIR/docker-compose.yaml")" == 'x-extra-hosts: &extra_hosts' ]]; then
        sed -i ':a;N;$!ba;s|\(  ekd-charon:\n[[:space:]]*<<: \[\)[[:space:]]*\*base[[:space:]]*\]|\1\n      *base,\n      *extra_hosts\n    ]\n    environment:\n      <<: *base-env|' "$TMP_DIR/docker-compose.yaml"
    else
        sed -i ':a;N;$!ba;s|\(  ekd-charon:\n[[:space:]]*<<: \[\)[[:space:]]*\*base[[:space:]]*\]|\1\n      *base,\n      # *extra_hosts\n    ]\n    environment:\n      <<: *base-env|' "$TMP_DIR/docker-compose.yaml"
    fi
} >> $UPDATE_LOG_FILE 2>&1

show_and_apply_changes() {
    files=(".env" "docker-compose.yaml" "ekd-config/custom.conf" "ekd-config/ekd-file/custom.conf" "nginx.conf")
    set +eu
    for file in "${files[@]}"; do
        out=$(diff -C 3 $file "$TMP_DIR/$file")
        if [[ "$out" != "" ]]; then
            printf "%b%s%b\n" "$clr_ylw" "diff изменений в $file" "$clr_rst"
            log "$out"
            printf "$clr_grn"
            read -p "Нажмите Enter чтобы продолжить"
            printf "$clr_rst"            
        fi
    done
    set -eu

    read -p "Применить изменения? [y/N]: " -r
    echo
    if [[ $REPLY =~ ^[YyНн]$ ]]; then
        cp -r "$TMP_DIR/." .
    else
        log "Обновление отменено"
        exit 1
    fi
}

pull_images() {
    log "Удаляем старые образы"
    docker system prune -af --filter "until=$((24*5))h" | grep "Total reclaimed space:"
    log "Cкачиваем новые образы приложения"
    docker compose pull || docker-compose pull
}

restart_app() {
    read -p "Перезапустить приложение? [y/N]: " -r
    echo
    if [[ $REPLY =~ ^[YyНн]$ ]]; then
        docker compose up -d || docker-compose up -d
    else
        echo "Перезапуск отменен"
    fi
}

status_check() {
    log "Ожидание поднятия приложения..."
    containers=($(docker ps --format {{.Names}} | grep 'ekd' | grep -v -E 'charon|ui'))
    declare -A up_containers

    time_counter=0
    set +u
    set +e
    while [[ ${#up_containers[@]} -lt ${#containers[@]} ]]; do
        if [[ $time_counter -gt 20 ]]; then
            printf "%b%s%b\n" "$clr_red" "timeout" "$clr_rst"
            break
        fi
        
        for container in "${containers[@]}"; do
            if [[ -n ${up_containers[$container]} ]]; then
                continue
            fi

            status=$(docker inspect "$container" --format '{{.State.Health.Status}}' 2>/dev/null)

            if [[ "$status" == "healthy" ]]; then
                up_containers[$container]=1
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi

            if [[ "$status" == "unhealthy" ]] && [[ ${up_containers["ekd-monolith"]} -eq 1 ]]; then
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi
        done
        
        ((time_counter++))
        sleep 15
    done
    set -e
    set -u

    ui_ver=$(docker exec -it ekd-ui curl localhost:80/assets/json/version.json | grep -o '"version": *"[^"]*' | cut -d '"' -f 4 | cut -d '.' -f 2)
    if [[ "$ui_ver" == "$NEW_RELEASE" ]]; then
        printf "\t%b%s%b\n" "$clr_grn" "ekd-ui healthy!" "$clr_rst"
    fi
    
    log "Приложение встало!"
}

post_update() {
    :
}

pre_update_checks
pre_update_actions
configs_actions
show_and_apply_changes
set +u
if [[ -z "$1" ]]; then
    pull_images
    restart_app
    db_actions
    status_check
else
    printf "\n%bЗагрузка образов и перезапуск приложения пропущены.%b\n" "$clr_ylw" "$clr_rst"
fi
set -u
post_update

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
