#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="2"

NEW_RELEASE=91
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d:%H-%M-%S)"
UPDATE_LOG_FILE="logs/updates/$NEW_RELEASE.txt"
TMP_DIR=$(mktemp -d)

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

log() {
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1"
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1" >> $UPDATE_LOG_FILE
}

pre_update_checks() {
    ls docker-compose.yaml .env > /dev/null 2>&1 || { echo "скрипт необходимо запустить из директории с docker-compose.yaml и .env"; exit 4; }

    CURR_RELEASE=$(grep EKD_MONOLITH_VERSION .env | cut -d'=' -f2)
    if (( "$NEW_RELEASE" - "$CURR_RELEASE" > 1 )); then
        printf "%b\tПеред установкой релиза %b необходимо установить предыдущие релизы (установленный релиз - %b)%b\n" "$clr_red" "$NEW_RELEASE" "$CURR_RELEASE" "$clr_rst"
        exit 1
    fi

    if (( "$NEW_RELEASE" - "$CURR_RELEASE" == 0 )); then
        printf "%b\tУже установлен релиз %b%b\n" "$clr_red" "$CURR_RELEASE" "$clr_rst"
        exit 1
    fi

    echo "Проверка наличия необходимых пакетов:"

    set +u
    source /etc/os-release
    pkg_not_found=0

    # проверка пакетов по ID и ID_LIKE в /etc/os-release
    if [[ "$ID_LIKE" == *"debian"* ]] || [[ "$ID" == "ubuntu" || "$ID" == "debian" ]]; then
        PKGS=("docker" "bash" "uuid" "ping" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(dpkg --list)
    elif [[ "$ID_LIKE" == *"rhel"* ]] || [[ "$ID" == "fedora" || "$ID" == "rhel" || "$ID" == "centos" ]]; then
        PKGS=("docker" "bash" "util-linux" "iputils" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(yum list --installed)
    else
        echo 'Тип ОС не установлен. Проверка наличия пакета в $PATH'
        pkgs=("docker" "bash" "uuidgen" "ping" "curl" "wget" "netcat" "cron")

        set +e
        all_pkgs=""

        for dir in $(echo $PATH | tr ':' '\n'); do
            all_pkgs+=$(ls -m $dir 2>/dev/null | sed 's/,/\n/g' | sed 's/ //g')
        done

        for pkg in "${pkgs[@]}"; do
            pkgs=($(echo "$all_pkgs" | sort | grep -v '^$' | uniq))

            if [[ "${pkgs[*]}" =~ "$pkg" ]]; then
                printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
            else
                printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
                pkg_not_found=1
            fi
        done
        set -e
    fi

    for pkg in "${PKGS[@]}"; do
        result=$(echo "$INSTALLED_PKGS" | grep -E "$pkg")
        if [[ "$result" != "" ]]; then
            printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
        else
            printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
            pkg_not_found=1
        fi
    done

    if [[ "$pkg_not_found" -gt 0 ]]; then
        printf "%bНеобходимо установить необходимые пакеты перед обновлением! %b\n" "$clr_red" "$clr_rst"
        exit 1
    fi
    set -u

    # наличие свободного места
    disks=("/" "/var")
    echo
    for disk in "${disks[@]}"; do
        disk_space=$(df $disk --output=avail -x loop -x tmpfs | tail -n 1 | awk '{print int($1 / 1024 / 1024)}')
        if [[ $disk_space -lt 10 ]]; then
            printf "\t%bНа $disk недостаточно места ($disk_space). Для обновления необходимо 10ГБ.%b\n" "$clr_red" "$disk_space" "$clr_rst"
        else
            printf "\t%b$disk\tOK (%d GB free) %b\n" "$clr_grn" "$disk_space" "$clr_rst"
        fi
    done

    # Размещение файлов приложения в разделе жесткого диска, зарезервированного под ОС.
    if [[ "$(stat -c %d .)" -eq "$(stat -c %d /)" ]]; then
        printf "%b\tДиректория приложения расположена на диске с ОС!%b\n" "$clr_red" "$clr_rst"
    fi

    # Вынесение любого сервиса на отдельный сервер
    compose_config=($(docker compose config --services || docker-compose config --services ))
    all_services=("ekd-file-processing" "ekd-monolith" "ekd-showcase" "ekd-ui" "ekd_kafka" "postgresql" "ekd-api-gateway" "ekd-calendar" "ekd-charon" "ekd-chat" "ekd-file" "ekd-repeat-notification")

    set +u
    declare -A lookup
    for item in "${compose_config[@]}"; do
        lookup["$item"]=1
    done

    for item in "${all_services[@]}"; do
        if [[ -z "${lookup[$item]}" ]]; then
            printf "\t%b%b%b\n" "$clr_red" "На сервере не найден контейнер $item!" "$clr_rst"
        fi
    done
    set -u

    # конфиги/сторадж/т.д. в другой директории или их нельзя читать и редактировать
    files=(".env" "docker-compose.yaml" "nginx.conf" "ekd-config/custom.conf" "ekd-config/ekd-file/custom.conf")
    rw_files_count="${#files[@]}"
    missing_files_count=0
    for file in "${files[@]}"; do
        if ! ([[ -f $file ]] || [[ -d $file ]]); then
            printf "\t%b%b%b\n" "$clr_red" "Не найден $file в директории приложения!" "$clr_rst"
            ((missing_files_count++))
        elif ! ([[ -w $file ]] || [[ -r $file ]]); then
            printf "\t%b%b%b\n" "$clr_red" "Невозможно чтение или редактирование $file!" "$clr_rst"
            ((rw_files_count--))
        fi
    done
    if [[ $missing_files_count -gt 0 ]] || [[ $rw_files_count -lt "${#files[@]}" ]]; then
        exit 1
    fi

    # SMTP & SMS-шлюз
    if [[ "$(grep 'play.mailer' ekd-config/custom.conf)" != "" ]]; then
        printf "\t%b%b%b\n" "$clr_ylw" "Настроена отправка email на свой SMTP-сервер!" "$clr_rst"
    fi
    if [[ "$(grep 'notification.tenants.clientGateSender' ekd-config/custom.conf)" != "" ]]; then
        printf "\t%b%b%b\n" "$clr_ylw" "Настроена отправка SMS на свой SMS-шлюз!" "$clr_rst"
    fi

    # терминация SSL не в ekd-ui
    if [[ $(grep -E '^\s*[^#]*443 ssl' nginx.conf) == "" ]]; then
        printf "\t%b%b%b\n" "$clr_ylw" "Терминирование SSL происходит не в ekd-ui!" "$clr_rst"
    fi
}

pre_update_actions() {
    mkdir -p "$BACKUP_DIR"
    echo "Директория бекапа до обновления - $BACKUP_DIR"
    mkdir -p "logs/updates"
    touch "$UPDATE_LOG_FILE"

    mkdir -p "$TMP_DIR/ekd-config/ekd-file/"

    cp docker-compose.yaml nginx.conf .env ekd-config/custom.conf "$BACKUP_DIR"
    cp ekd-config/ekd-file/custom.conf "$BACKUP_DIR/ekd-file-custom.conf"

    cp .env docker-compose.yaml nginx.conf "$TMP_DIR"
    cp ekd-config/custom.conf "$TMP_DIR/ekd-config/custom.conf"
    cp ekd-config/ekd-file/custom.conf "$TMP_DIR/ekd-config/ekd-file/custom.conf"


    printf "%b%s%b\n" "$clr_ylw" "Конфигурация пересмотренных регулярных cron-задач" "$clr_rst"
    read -p "Введите пользователя хостовой ОС, от которого будут запускаться скрипты cron-задач приложения. Он должен иметь права на чтение и изменение файлов в директории приложения (по ум. root): " cron_user
    cron_user="${cron_user:-root}"
}

db_actions() {
    :
}

configs_actions() {
    log "обновление версий контейнеров"

    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    #sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_NEWS_VERSION=.*/EKD_NEWS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_BUSINESS_JOURNEYS_VERSION=.*/EKD_BUSINESS_JOURNEYS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"

    # переменные окружения для пересмотренных cron-задач
    echo -e "\nHRLINK_HOME=$(pwd)\nCRON_USER=$cron_user\nCRON_HOUR=00\nCRON_MINUTE=00" >> "$TMP_DIR/.env"
    sed -i "/container_name: ekd-charon/i\      HRLINK_HOME: \${HRLINK_HOME}\n      CRON_USER: \${CRON_USER}\n      CRON_HOUR: \${CRON_HOUR}\n      CRON_MINUTE: \${CRON_MINUTE}" "$TMP_DIR/docker-compose.yaml"

    sed -i '/SHARED_FILE_HOST/d' "$TMP_DIR/docker-compose.yaml"
} >> $UPDATE_LOG_FILE 2>&1

show_and_apply_changes() {
    files=(".env" "docker-compose.yaml" "ekd-config/custom.conf" "ekd-config/ekd-file/custom.conf" "nginx.conf")
    set +eu
    for file in "${files[@]}"; do
        out=$(diff -C 3 $file "$TMP_DIR/$file")
        if [[ "$out" != "" ]]; then
            printf "%b%s%b\n" "$clr_ylw" "diff изменений в $file" "$clr_rst"
            log "$out"
            printf "$clr_grn"
            read -p "Нажмите Enter чтобы продолжить"
            printf "$clr_rst"
        fi
    done
    set -eu

    while true; do
        read -rp "Применить изменения? [y/N]: " reply
        echo
        case "$reply" in
            [Yy])
                cp -r "$TMP_DIR/." .
                break
                ;;
            [Nn]|"")
                echo "Обновление отменено"
                exit 1
                ;;
            *)
                echo "Введите y (yes) или n (no)"
                ;;
        esac
    done
}

pull_images() {
    log "Удаляем старые образы"
    docker system prune -af --filter "until=$((24*5))h" | grep "Total reclaimed space:"
    log "Cкачиваем новые образы приложения"
    docker compose pull || docker-compose pull
}

restart_app() {
    while true; do
        read -rp "Перезапустить приложение? [y/N]: " reply
        echo
        case "$reply" in
            [Yy])
                docker compose up -d || docker-compose up -d
                break
                ;;
            [Nn]|"")
                echo "Перезапуск отменен"
                printf "\t%b%b%b\n" "$clr_red" "Приложение не запущено!" "$clr_rst"
                break
                ;;
            *)
                echo "Введите y (yes) или n (no)"
                ;;
        esac
    done
}

status_check() {
    log "Ожидание поднятия приложения..."
    containers=($(docker ps --format {{.Names}} | grep 'ekd' | grep -v -E 'charon|ui'))
    declare -A up_containers

    time_counter=0
    set +u
    set +e
    while [[ ${#up_containers[@]} -lt ${#containers[@]} ]]; do
        if [[ $time_counter -gt 20 ]]; then
            printf "%b%s%b\n" "$clr_red" "timeout" "$clr_rst"
            break
        fi

        for container in "${containers[@]}"; do
            if [[ -n ${up_containers[$container]} ]]; then
                continue
            fi

            status=$(docker inspect "$container" --format '{{.State.Health.Status}}' 2>/dev/null)

            if [[ "$status" == "healthy" ]]; then
                up_containers[$container]=1
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi

            if [[ "$status" == "unhealthy" ]] && [[ ${up_containers["ekd-monolith"]} -eq 1 ]]; then
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi
        done

        ((time_counter++))
        sleep 15
    done
    set -e
    set -u

    ui_ver=$(docker exec -it ekd-ui curl localhost:80/assets/json/version.json | grep -o '"version": *"[^"]*' | cut -d '"' -f 4 | cut -d '.' -f 2)
    if [[ "$ui_ver" == "$NEW_RELEASE" ]]; then
        printf "\t%b%s%b\n" "$clr_grn" "ekd-ui healthy!" "$clr_rst"
    fi

    log "Приложение встало!"
}

post_update() {
    # symlink crontab'а пересемотренных задач в /etc/cron.d/
    log "Создание symlink для включения crontab приложения"
    sudo ln -sf "$(pwd)/scripts/cron/crontab" /etc/cron.d/hrlink

    log "Удаление старых записей из crontab пользователя"
    (crontab -l | grep -v -F "(docker compose pull || docker-compose pull)") | crontab -
    (crontab -l | grep -v -F "docker system prune -af") | crontab -
}

pre_update_checks
pre_update_actions
configs_actions
show_and_apply_changes
set +u
if [[ -z "$1" ]]; then
    pull_images
    restart_app
    db_actions
    status_check
else
    printf "\n%bЗагрузка образов и перезапуск приложения пропущены.%b\n" "$clr_ylw" "$clr_rst"
fi
set -u
post_update

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
