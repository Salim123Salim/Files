#!/bin/bash

hrlink_home=$(docker inspect --format '{{ index .Config.Labels "com.docker.compose.project.working_dir" }}' ekd-monolith)

cd $hrlink_home

# применение хотфиксов
docker compose up -d

# удаление неиспользуемых образов старше 1 недели
docker system prune -af --filter "until=$((24*5))h"
