#!/usr/bin/env bash

hrlink_home=$(docker inspect --format '{{ index .Config.Labels "com.docker.compose.project.working_dir" }}' ekd-monolith)

cd $hrlink_home

exited_cnt=$(docker compose ps -a --format "{{.Names}} {{.Status}}" | grep "Exited" | wc -l)

if [[ $exited_cnt -gt 0 ]]; then
    echo "$(date) ERROR: существуют контейнеры со статусом Exited. Перезапуск приложения."
    echo "$(docker compose ps -a --format 'table {{.Names}}\t{{.Status}}' | grep 'Exited')"
    docker compose down && docker compose up -d
fi
