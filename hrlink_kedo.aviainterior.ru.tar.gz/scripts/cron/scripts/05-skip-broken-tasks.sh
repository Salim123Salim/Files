#!/usr/bin/env bash

main_dbname=$(docker exec ekd-charon bash /internal/run_in_db.sh ekd_metadata "SELECT DISTINCT database_name FROM tenant_database_connection LIMIT 1;")

docker exec ekd-charon bash /internal/run_in_db.sh $main_dbname "UPDATE ekd_ca.local_nqes_user_confirmation_task SET skipping=true WHERE version >= 1000;"
docker exec ekd-charon bash /internal/run_in_db.sh $main_dbname "UPDATE ekd_ca.zorro_nqes_user_confirmation_task SET skipping=true WHERE version >= 1000;"
