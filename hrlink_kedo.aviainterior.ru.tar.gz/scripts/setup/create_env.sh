#!/bin/bash
set -e

source credentials.txt

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

CURRENT_VERSION=97

ls docker-compose.yaml > /dev/null 2>&1 || { echo "скрипт нужно запустить из директории с docker-compose.yaml"; exit 4; }

ENV_FILE='.env'
ls "$ENV_FILE" > /dev/null 2>&1 && mv "$ENV_FILE" "$ENV_FILE".bak
touch "$ENV_FILE"

read -p "Введите домен приложения:" domain
[ -z "${domain}" ] && echo "Домен приложения не должен быть пустым." && exit 1

while true; do
    read -rp "Будет ли использоваться внешний кластер БД? [y/N]: " reply
    case "$reply" in
        [Yy])
            read -rp "Введите hostname/ip внешнего кластера: " db_host
            read -rp "Введите порт внешнего кластера: " db_port

            external_db_cluster=1

            # отключение локального кластера
            cat <<EOF > docker-compose.override.yaml
services:
  postgresql:
    profiles: ["disabled"]
EOF

            break
            ;;
        [Nn]|"")
            db_host="postgresql"
            db_port="5432"

            external_db_cluster=0

            break
            ;;
        *)
            echo "Введите y (yes) или n (no)"
            ;;
    esac
done

read -p "Введите пользователя хостовой ОС, от которого будут запускаться скрипты cron-задач приложения. Он должен иметь права на чтение и изменение файлов в директории приложения (по ум. root): " cron_user
cron_user="${cron_user:-root}"

# расчет MEM_ALLOC'ов контейнеров приложения в зависимости от количества ОЗУ на сервере
# оставшаяся ОЗУ будет занята ekd-postgresql, ekd-kafka, ekd-ui и ОС хоста
total_memory_kb=$(cat /proc/meminfo | grep -i 'memtotal' | grep -o '[[:digit:]]*')
total_memory_mb=$(($total_memory_kb / 1024))

mem_alloc_monolith=$(($total_memory_mb * 20 / 100)) # ekd-monolith - 20%
mem_alloc_file=$(($total_memory_mb / 10)) # ekd-file - 10%
mem_alloc_file_proc=$(($total_memory_mb * 25 / 100)) # ekd-file-processing - 25%
mem_alloc_other=$(($total_memory_mb * 5 / 100 )) # ekd-api-gateway, ekd-calendar, ekd-repeat-notification, ekd-chat, ekd-showcase - 5% каждый

# если текущий дистро - Astra Linux, ставить образы с постфиксом `-astra`
MONOLITH_VERSION=$CURRENT_VERSION
FILE_VERSION=$CURRENT_VERSION
source /etc/os-release
if [[ "$ID" == "astra" ]]; then
    MONOLITH_VERSION="$CURRENT_VERSION-astra"
    FILE_VERSION="$CURRENT_VERSION-astra"
fi

cat<<EOF > "$ENV_FILE"
EKD_KAFKA_VERSION="3.6.2"
EKD_POSTGRESQL_VERSION="16-alpine"
EKD_VALKEY_VERSION="8-alpine"

EKD_UI_VERSION=$CURRENT_VERSION
EKD_MONOLITH_VERSION=$MONOLITH_VERSION
EKD_FILE_VERSION=$FILE_VERSION
EKD_FILE_PROCESSING_VERSION=$CURRENT_VERSION
EKD_API_GATEWAY_VERSION=$CURRENT_VERSION
EKD_CALENDAR_VERSION=$CURRENT_VERSION
EKD_CHAT_VERSION=$CURRENT_VERSION
EKD_REPEAT_NOTIFICATION_VERSION=$CURRENT_VERSION
EKD_SHOWCASE_VERSION=$CURRENT_VERSION
EKD_BUSINESS_JOURNEYS_VERSION=$CURRENT_VERSION
EKD_NEWS_VERSION=$CURRENT_VERSION

EKD_CHARON_VERSION=latest
EKD_SERVICE_CHECKER_VERSION=latest

CLIENT_DOMAIN='${domain}'
AVAILABLE_HOST='$(echo "${domain}" | grep -Po "\w+\.\K.*.\w+")'
ALLOWED_HOST='$(echo "${domain}" | grep -Po "\w+\K\..*.\w+")'

LICENSE_MANAGER_TOKEN=${LICENSE_MANAGER_TOKEN}

DB_SECRET_KEY='$(head -c 36 /dev/urandom | base64)'
PGDATA="/var/lib/postgresql/data/pgdata"
POSTGRES_DB="postgres"
POSTGRES_HOST="${db_host}"
POSTGRES_PORT=${db_port}
POSTGRES_USERNAME="postgres"
POSTGRES_PASSWORD='$(head -c 36 /dev/urandom | base64)'
MIGRATIONS_USER_PASSWORD='$(head -c 36 /dev/urandom | base64)'

VALKEY_USERNAME=hrlink
VALKEY_PASSWORD='$(uuidgen)'

OAUTH_SECRET='$(head -c 36 /dev/urandom | base64)'
WEB_SERVER_API_TOKEN='$(head -c 36 /dev/urandom | base64)'
HTTP_SECRET='$(uuidgen)'
SESSION_KEYSTORE_PASSWORD='$(uuidgen)'
ZORRO_TOKEN_SECRET_KEY="$(head -c 32 /dev/random | base64)"
PECHKIN_TOKEN_SECRET_KEY="$(head -c 32 /dev/random | base64)"
STORAGE_ENCRYPTION_AES256_KEY="$(head -c 32 /dev/random | base64)"
TRANSFER_ENCRYPTION_AES256_KEY="$(head -c 32 /dev/random | base64)"

KAFKA_HOSTNAME='kafka'
CLUSTER_ID='$(LC_ALL=C tr -dc 'A-Za-z0-9' < /dev/urandom | head -c 16 | base64)'
KAFKA_BROKER_URL=\${KAFKA_HOSTNAME}:9092
NODE_ID=1

MONOLITH_MEM_ALLOC=$mem_alloc_monolith
FILE_PROCESSING_MEM_ALLOC=$mem_alloc_file_proc
FILE_MEM_ALLOC=$mem_alloc_file
API_GATEWAY_MEM_ALLOC=$mem_alloc_other
CALENDAR_MEM_ALLOC=$mem_alloc_other
REPEAT_NOTIFICATION_MEM_ALLOC=$mem_alloc_other
CHAT_MEM_ALLOC=$mem_alloc_other
SHOWCASE_MEM_ALLOC=$mem_alloc_other
BUSINESS_JOURNEYS_MEM_ALLOC=$mem_alloc_other
NEWS_MEM_ALLOC=$mem_alloc_other

FILE_PROCESSING_CREATE_PRINT_FORM_TASK_POOL=$(( $(nproc) / 2 ))
FILE_PROCESSING_CONVERT_PDFA_POOL=$(( $(nproc) * 8 / 10 ))

HRLINK_HOME=$(pwd)
CRON_USER=$cron_user
CRON_HOUR=00
CRON_MINUTE=00
EOF

if [[ $external_db_cluster -eq 1 ]]; then
    source .env
    printf "%b%s%b\n" "$clr_ylw" "На внешнем кластере БД ${db_host}:${db_port} необходимо создать пользователей и базы данных приложения:" "$clr_rst"
    grep -E "CREATE (USER|DATABASE)" scripts/setup/postgresql-init.sh | sed "s|\$MIGRATIONS_USER_PASSWORD|${MIGRATIONS_USER_PASSWORD}|g"
    read -p "После создания нажмите Enter чтобы продолжить"
    printf "%b%s%b\n" "$clr_ylw" "Рекомендуемые настройки кластера:" "$clr_rst"
    grep 'ALTER' scripts/setup/postgresql-init.sh | sed -n 's/.*-c "\([^"]*\)".*/\1/p'
    printf "%b%s%b\n" "$clr_ylw" "Рекомендуется выставление trusted = true в control-файле расширения dblink. Это расширение может использоваться в скриптах технической поддержки. В образе postgresql, поставляемым HRlink, эта опция проставляется по умолчанию." "$clr_rst"
    echo "Пример корректной настройки на ОС Ubuntu:
  $ cat /usr/share/postgresql/<version>/extension/dblink.control
    # dblink extension
    comment = 'connect to other PostgreSQL databases from within a database'
    default_version = '1.2'
    module_pathname = '$libdir/dblink'
    relocatable = true
    trusted = true
"
    read -p "Нажмите Enter чтобы продолжить"
fi
