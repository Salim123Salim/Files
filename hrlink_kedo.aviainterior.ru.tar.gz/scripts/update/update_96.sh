#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="2"

NEW_RELEASE=96
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d-%H-%M-%S)"
LOG_FILE="logs/updates/$NEW_RELEASE.txt"
TMP_DIR=$(mktemp -d)

source scripts/util/common.sh
source scripts/util/update_common.sh
source scripts/util/docker_common.sh

local_pre_update_checks() {
    pre_update_checks

    postgresql_version=$(grep EKD_POSTGRESQL_VERSION .env | cut -d'=' -f2 | sed 's/"//g')

    if [[ $(docker compose config --services | grep postgresql) != "" ]] && [[ "$postgresql_version" != "16-alpine" ]]; then
        printf "\t%b%b%b\n" "$clr_red" "Локальный кластер postgresql не обновлен на версию 16! Обновление невозможно." "$clr_rst"
        exit 1
    fi
}

db_actions() {
    if [[ -d postgresql-data/pgdata-13 ]]; then
        log "Удаление старого кластера postgresql (rm -rf postgresql-data/pgdata-13)"
        rm -rf postgresql-data/pgdata-13 || sudo rm -rf postgresql-data/pgdata-13
    fi
}

configs_actions() {
    log "обновление версий контейнеров"

    # если текущий дистро - Astra Linux, ставить образы с постфиксом `-astra`
    MONOLITH_VERSION="$NEW_RELEASE"
    FILE_VERSION="$NEW_RELEASE"
    source /etc/os-release
    if [[ "$ID" == "astra" ]]; then
        MONOLITH_VERSION="$NEW_RELEASE-astra"
        FILE_VERSION="$NEW_RELEASE-astra"
    fi

    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$MONOLITH_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$FILE_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_NEWS_VERSION=.*/EKD_NEWS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_BUSINESS_JOURNEYS_VERSION=.*/EKD_BUSINESS_JOURNEYS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"

    # добавление переменных для версий контейнеров ekd-charon ekd-service-checker
    sed -i "/CLIENT_DOMAIN.*/iEKD_CHARON_VERSION=latest" "$TMP_DIR/.env"
    sed -i "/CLIENT_DOMAIN.*/iEKD_SERVICE_CHECKER_VERSION=latest\n" "$TMP_DIR/.env"
    sed -i "s/ekd-charon:latest/ekd-charon:\${EKD_CHARON_VERSION}/" "$TMP_DIR/docker-compose.yaml"
    sed -i "s/service-checker:latest/service-checker:\${EKD_SERVICE_CHECKER_VERSION}/" "$TMP_DIR/docker-compose.yaml"

    # использование токена лицензии для взаимодействия с сервисом уведомлений
    sed -i "s/PINBOARD_API_TOKEN: \${PINBOARD_API_TOKEN}/PINBOARD_API_TOKEN: \${LICENSE_MANAGER_TOKEN}/" "$TMP_DIR/docker-compose.yaml"
    sed -i "/PINBOARD_API_TOKEN/d" "$TMP_DIR/.env"

    is_monolith_multiinstance=$(grep "application.isMultiInstance = true" ekd-config/custom.conf | cut -d'=' -f2 | sed 's/ //g' || echo "false")
    if [[ $is_monolith_multiinstance == "true" ]]; then
        echo "taskProcessing.eventProcessingEnabled = false" >> "$TMP_DIR/ekd-config/custom.conf"
    fi
}

post_update() {
    :
}

local_pre_update_checks
pre_update_actions
configs_actions 2>&1 | tee -a "$LOG_FILE"
show_and_apply_changes
set +u
if [[ -z "$1" ]]; then
    pull_images
    restart_app
    db_actions 2>&1 | tee -a "$LOG_FILE"
    status_check
else
    printf "\n%bЗагрузка образов и перезапуск приложения пропущены.%b\n" "$clr_ylw" "$clr_rst"
fi
set -u
post_update 2>&1 | tee -a "$LOG_FILE"

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
