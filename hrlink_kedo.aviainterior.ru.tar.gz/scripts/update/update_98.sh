#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="2"

NEW_RELEASE=98
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d-%H-%M-%S)"
LOG_FILE="logs/updates/$NEW_RELEASE.txt"
TMP_DIR=$(mktemp -d)

source scripts/util/common.sh
source scripts/util/update_common.sh
source scripts/util/docker_common.sh

local_pre_update_checks() {
    pre_update_checks

    postgresql_version=$(grep EKD_POSTGRESQL_VERSION .env | cut -d'=' -f2 | sed 's/"//g')

    if [[ $(docker compose config --services | grep postgresql) != "" ]] && [[ "$postgresql_version" != "16-alpine" ]]; then
        printf "\t%b%b%b\n" "$clr_red" "Локальный кластер postgresql не обновлен на версию 16! Обновление невозможно." "$clr_rst"
        exit 1
    fi
}

db_actions() {
    :
}

configs_actions() {
    log "обновление версий контейнеров"

    # если текущий дистро - Astra Linux, ставить образы с постфиксом `-astra`
    MONOLITH_VERSION="$NEW_RELEASE"
    FILE_VERSION="$NEW_RELEASE"
    source /etc/os-release
    if [[ "$ID" == "astra" ]]; then
        MONOLITH_VERSION="$NEW_RELEASE-astra"
        FILE_VERSION="$NEW_RELEASE-astra"
    fi

    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$MONOLITH_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$FILE_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_NEWS_VERSION=.*/EKD_NEWS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_BUSINESS_JOURNEYS_VERSION=.*/EKD_BUSINESS_JOURNEYS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"

    # переименование DOCKER_NEXUS_LINK в DOCKER_REGISTRY_URL
    sed -i 's/DOCKER_NEXUS_LINK/DOCKER_REGISTRY_URL/g' "$TMP_DIR/docker-compose.yaml"
    sed -i 's/DOCKER_NEXUS_LINK/DOCKER_REGISTRY_URL/g' "$TMP_DIR/.env"
    files=( "template.yaml" "business-journeys.yaml" "news.yaml" "valkey.yaml" "monitoring.yaml" )
    for file in "${files[@]}"; do
        if [[ -f $TMP_DIR/compose.d/$file ]]; then
            sed -i 's/docker.hr-link.ru/${DOCKER_REGISTRY_URL:-docker.hr-link.ru}/g' "$TMP_DIR/compose.d/$file"
            sed -i 's/DOCKER_NEXUS_LINK/DOCKER_REGISTRY_URL/g' "$TMP_DIR/compose.d/$file"
        fi
    done

    # перемещение скрипта инициализации БД
    sed -i 's#./scripts/postgresql/:/docker-entrypoint-initdb.d/#./scripts/setup/postgresql-init.sh:/docker-entrypoint-initdb.d/postgres-init.sh:ro,z#g' "$TMP_DIR/docker-compose.yaml"
}

post_update() {
    tenant_id_hash=$(docker exec ekd-charon /internal/run_in_db.sh ekd_metadata "select id from tenant" | md5sum | awk '{print $1}')
    needed_hashes=( "8487da2f3cf9207e1ff7312b912739c3" "693bceff1db81556a6f7611433164a94" )
    match=false
    for hash in "${needed_hashes[@]}"; do
        if [[ "$hash" == "$tenant_id_hash" ]]; then
            match=true
            break
        fi
    done

    if [[ "$match" == "false" ]]; then
        docker exec ekd-charon /internal/run_in_db.sh ekd_metadata "update tenant_settings set document_bulk_signing_disabled_date = now()"
    fi
}

local_pre_update_checks
pre_update_actions
configs_actions 2>&1 | tee -a "$LOG_FILE"
show_and_apply_changes
set +u
if [[ -z "$1" ]]; then
    pull_images
    restart_app
    db_actions 2>&1 | tee -a "$LOG_FILE"
    status_check
else
    printf "\n%bЗагрузка образов и перезапуск приложения пропущены.%b\n" "$clr_ylw" "$clr_rst"
fi
set -u
post_update 2>&1 | tee -a "$LOG_FILE"

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
