#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="8"

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

log() {
    printf "$1$2$clr_rst\n"
}

set +u
if [[ -z "$1" ]]; then
    log "$clr_red" "Необходимо передать новый релиз первым параметром"
    log "$clr_ylw" "Пример: ./scripts/update/update_master.sh 95"
    exit
fi
set -u

ls docker-compose.yaml .env > /dev/null 2>&1 || { echo "скрипт необходимо запустить из директории с docker-compose.yaml и .env"; exit 4; }

SCRIPT_PATH="./scripts/update/update_$1.sh"

log "$clr_ylw" "Скачивание актуальных скриптов через ekd-charon"
docker compose pull ekd-charon || docker-compose pull ekd-charon
docker compose up -d ekd-charon || docker-compose up -d ekd-charon

sleep 2

if [[ ! -f "$SCRIPT_PATH" ]]; then
    log "$clr_red" "Скрипт обновления на релиз $1 не найден!"
fi

log "$clr_ylw" "Запуск $SCRIPT_PATH"
bash "$SCRIPT_PATH"
