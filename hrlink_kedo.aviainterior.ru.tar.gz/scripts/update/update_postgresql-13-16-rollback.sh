#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="3"

NEW_RELEASE="rollback_pg_upgrade-13-16"
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d:%H-%M-%S)"
UPDATE_LOG_FILE="logs/updates/$NEW_RELEASE.txt"
TMP_DIR=$(mktemp -d)

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

log() {
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1"
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1" >> $UPDATE_LOG_FILE
}

pre_update_checks() {
    ls docker-compose.yaml .env > /dev/null 2>&1 || { echo "скрипт необходимо запустить из директории с docker-compose.yaml и .env"; exit 4; }

    echo "Проверка наличия необходимых пакетов:"

    set +u
    source /etc/os-release
    pkg_not_found=0

    # проверка пакетов по ID и ID_LIKE в /etc/os-release
    if [[ "$ID_LIKE" == *"debian"* ]] || [[ "$ID" == "ubuntu" || "$ID" == "debian" ]]; then
        PKGS=("docker" "bash" "uuid" "ping" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(dpkg --list)
    elif [[ "$ID_LIKE" == *"rhel"* ]] || [[ "$ID" == "fedora" || "$ID" == "rhel" || "$ID" == "centos" ]]; then
        PKGS=("docker" "bash" "util-linux" "iputils" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(yum list --installed)
    else
        echo 'Тип ОС не установлен. Проверка наличия пакета в $PATH'
        pkgs=("docker" "bash" "uuidgen" "ping" "curl" "wget" "netcat" "cron")

        set +e
        all_pkgs=""

        for dir in $(echo $PATH | tr ':' '\n'); do
            all_pkgs+=$(ls -m $dir 2>/dev/null | sed 's/,/\n/g' | sed 's/ //g')
        done

        for pkg in "${pkgs[@]}"; do
            pkgs=($(echo "$all_pkgs" | sort | grep -v '^$' | uniq))

            if [[ "${pkgs[*]}" =~ "$pkg" ]]; then
                printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
            else
                printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
                pkg_not_found=1
            fi
        done
        set -e
    fi

    for pkg in "${PKGS[@]}"; do
        result=$(echo "$INSTALLED_PKGS" | grep -E "$pkg")
        if [[ "$result" != "" ]]; then
            printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
        else
            printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
            pkg_not_found=1
        fi
    done

    if [[ "$pkg_not_found" -gt 0 ]]; then
        printf "%bНеобходимо установить необходимые пакеты перед обновлением! %b\n" "$clr_red" "$clr_rst"
        exit 1
    fi
    set -u

    # наличие свободного места
    disks=("/" "/var")
    echo
    for disk in "${disks[@]}"; do
        disk_space=$(df $disk --output=avail -x loop -x tmpfs | tail -n 1 | awk '{print int($1 / 1024 / 1024)}')
        if [[ $disk_space -lt 10 ]]; then
            printf "\t%bНа $disk недостаточно места ($disk_space). Для обновления необходимо 10ГБ.%b\n" "$clr_red" "$clr_rst"
        else
            printf "\t%b$disk\tOK (%d GB free) %b\n" "$clr_grn" "$disk_space" "$clr_rst"
        fi
    done

    # проверка наличия места в postgresql-data для обновления pg
    used_pg_space=$(du -sb ./postgresql-data/pgdata | awk '{print int($1 / 1024 / 1024 / 1024)}')
    free_disk_space=$(df ./postgresql-data --output=avail -x loop -x tmpfs | tail -n 1 | awk '{print int($1 / 1024 / 1024)}')
    needed_space=$((2 * used_pg_space))
    if (( free_disk_space < 2 * needed_space )); then
        printf "\t%b В ./postgresql-data недостаточно места ($free_disk_space). Для обновления необходимо $needed_space ГБ.%b\n" "$clr_red" "$clr_rst"
        exit 1
    else
        printf "\t%b$disk\tOK (%d GB free) %b\n" "$clr_grn" "$free_disk_space" "$clr_rst"
    fi

    # Размещение файлов приложения в разделе жесткого диска, зарезервированного под ОС.
    if [[ "$(stat -c %d .)" -eq "$(stat -c %d /)" ]]; then
        printf "%b\tДиректория приложения расположена на диске с ОС!%b\n" "$clr_red" "$clr_rst"
    fi

    # конфиги/сторадж/т.д. в другой директории или их нельзя читать и редактировать
    files=(".env" "docker-compose.yaml")
    rw_files_count="${#files[@]}"
    missing_files_count=0
    for file in "${files[@]}"; do
        if ! ([[ -f $file ]] || [[ -d $file ]]); then
            printf "\t%b%b%b\n" "$clr_red" "Не найден $file в директории приложения!" "$clr_rst"
            ((missing_files_count++))
        elif ! ([[ -w $file ]] || [[ -r $file ]]); then
            printf "\t%b%b%b\n" "$clr_red" "Невозможно чтение или редактирование $file!" "$clr_rst"
            ((rw_files_count--))
        fi
    done
    if [[ $missing_files_count -gt 0 ]] || [[ $rw_files_count -lt "${#files[@]}" ]]; then
        exit 1
    fi

    # аутентифицирован ли текущий пользователь в docker registry
    DOCKER_NEXUS_LINK=$(grep -E '^DOCKER_NEXUS_LINK=' .env | cut -d'=' -f2-) || true
    DOCKER_NEXUS_LINK="${DOCKER_NEXUS_LINK:-docker.hr-link.ru}"
    DOMAIN="${DOCKER_NEXUS_LINK%%/*}"
    not_auth=0
    if ! grep -q "\"$DOMAIN\"" "$HOME/.docker/config.json"; then
        printf "\t%bТекущий пользователь (%s) не аутентифицирован в Docker Registry (%s)%b\n" "$clr_red" "$(whoami)" "$DOMAIN" "$clr_rst"
        not_auth=1
    fi

    if [[ $not_auth == 1 ]] && [[ "$DOMAIN" == "docker.hr-link.ru" ]]; then
        exit 1
    fi
}

pre_update_actions() {
    mkdir -p "$BACKUP_DIR"
    echo "Директория бекапа до обновления - $BACKUP_DIR"
    mkdir -p "logs/updates"
    touch "$UPDATE_LOG_FILE"

    mkdir -p "$TMP_DIR/ekd-config/ekd-file/"

    cp docker-compose.yaml .env "$BACKUP_DIR"

    cp .env docker-compose.yaml "$TMP_DIR"

    docker compose down || docker-compose down
}

db_actions() {
    # проверка что postgresql запущен на этом сервере
    services=$(docker compose config --services 2>/dev/null || docker-compose config --services 2>/dev/null)
    if ! printf '%s\n' "$services" | grep postgresql; then
        printf "\t%b%b%b\n" "$clr_ylw" "ekd-postgresql вынесен на отдельный сервер или используется свой кластер" "$clr_rst"
        exit 0
    fi

    # проверка что текущая версия подлежит обновлению
    postgres_version=$(grep -m1 '^EKD_POSTGRESQL_VERSION=' .env 2>/dev/null | cut -d= -f2- | tr -d ' "')
    if [[ "$postgres_version" == "13-alpine" ]]; then
        printf "\t%b%b%b\n" "$clr_ylw" "ekd-postgresql уже на версии 13-alpine" "$clr_rst"
        exit 0
    fi

    # замена директорий кластеров
    sudo mv postgresql-data/pgdata postgresql-data/pgdata-16 && sudo mv postgresql-data/pgdata-13 postgresql-data/pgdata
}

configs_actions() {
    log "обновление версий контейнеров"

    # обновление версии контейнера
    sed -i "s/EKD_POSTGRESQL_VERSION=16-alpine/EKD_POSTGRESQL_VERSION=13-alpine/" "$TMP_DIR/.env"
} >> $UPDATE_LOG_FILE 2>&1

show_and_apply_changes() {
    files=(".env" "docker-compose.yaml")
    set +eu
    for file in "${files[@]}"; do
        out=$(diff -C 3 $file "$TMP_DIR/$file")
        if [[ "$out" != "" ]]; then
            printf "%b%s%b\n" "$clr_ylw" "diff изменений в $file" "$clr_rst"
            log "$out"
            printf "$clr_grn"
            read -p "Нажмите Enter чтобы продолжить"
            printf "$clr_rst"
        fi
    done
    set -eu

    while true; do
        read -rp "Применить изменения? [y/N]: " reply
        echo
        case "$reply" in
            [Yy])
                cp -r "$TMP_DIR/." .
                break
                ;;
            [Nn]|"")
                echo "Обновление отменено"
                exit 1
                ;;
            *)
                echo "Введите y (yes) или n (no)"
                ;;
        esac
    done
}

pull_images() {
    log "Удаляем старые образы"
    docker system prune -af --filter "until=$((24*5))h" | grep "Total reclaimed space:"
    log "Cкачиваем новые образы приложения"
    docker compose pull || docker-compose pull
}

restart_app() {
    while true; do
        read -rp "Перезапустить приложение? [y/N]: " reply
        echo
        case "$reply" in
            [Yy])
                docker compose up -d || docker-compose up -d
                break
                ;;
            [Nn]|"")
                echo "Перезапуск отменен"
                printf "\t%b%b%b\n" "$clr_red" "Приложение не запущено!" "$clr_rst"
                break
                ;;
            *)
                echo "Введите y (yes) или n (no)"
                ;;
        esac
    done
}

status_check() {
    log "Ожидание поднятия приложения..."
    containers=($(docker ps --format {{.Names}} | grep 'ekd' | grep -v -E 'charon|ui'))
    declare -A up_containers

    time_counter=0
    set +u
    set +e
    while [[ ${#up_containers[@]} -lt ${#containers[@]} ]]; do
        if [[ $time_counter -gt 20 ]]; then
            printf "%b%s%b\n" "$clr_red" "timeout" "$clr_rst"
            break
        fi

        for container in "${containers[@]}"; do
            if [[ -n ${up_containers[$container]} ]]; then
                continue
            fi

            status=$(docker inspect "$container" --format '{{.State.Health.Status}}' 2>/dev/null)

            if [[ "$status" == "healthy" ]]; then
                up_containers[$container]=1
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi

            if [[ "$status" == "unhealthy" ]] && [[ ${up_containers["ekd-monolith"]} -eq 1 ]]; then
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi
        done

        ((time_counter++))
        sleep 15
    done
    set -e
    set -u

    ui_ver=$(docker exec -it ekd-ui curl localhost:80/assets/json/version.json | grep -o '"version": *"[^"]*' | cut -d '"' -f 4 | cut -d '.' -f 2)
    if [[ "$ui_ver" == "$NEW_RELEASE" ]]; then
        printf "\t%b%s%b\n" "$clr_grn" "ekd-ui healthy!" "$clr_rst"
    fi

    log "Приложение встало!"
}

post_update() {
    :
}

pre_update_checks
pre_update_actions
db_actions
configs_actions
show_and_apply_changes
pull_images
restart_app
status_check
post_update

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
